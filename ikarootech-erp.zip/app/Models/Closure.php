<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Closure extends Model
{
    //
    protected $fillable = [
        "starting_date",
        "region",
        "ending_date"
    ];
}
