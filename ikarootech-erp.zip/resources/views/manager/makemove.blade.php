@extends("Layouts.ManagerLayout")
@section("content")
<div class="p-5 ">
</div>
@endsection