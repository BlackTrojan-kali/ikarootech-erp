@extends("Layouts.comLayout")
@section("content")
<div>
    @dd($sales)
</div>
@endsection
