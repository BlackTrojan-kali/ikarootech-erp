<?php $__env->startSection('content'); ?>
    <div class="w-full">
        <center>

            <div class="w-6/12 border-2 border-gray-300">
                <div class="modal-head">
                    <h1>Creer un nouveau prix pour categorie</h1>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" class="p-2" action="<?php echo e(route('store-client-price')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Categorie:</label>
                        <select name="client">
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('client')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('client')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs ">
                        <label for="">Region:</label>
                        <select name="region">
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region->region); ?>">
                                        <?php echo e($region->region); ?>

                                    </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="modal-champs">
                        <label for="">Article:</label>
                        <select name="article">
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($article->type == 'accessoire'): ?>
                                    <option value="<?php echo e($article->id); ?>">
                                        <?php echo e($article->title); ?>


                                    </option>
                                <?php else: ?>
                                    <?php if($article->state > 0): ?>
                                        <option value="<?php echo e($article->id); ?>">
                                            <?php echo e($article->type); ?> <?php echo e($article->weight . ' KG'); ?>


                                        </option>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('article')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('article')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Prix:</label>
                        <input type="number" name="price">
                        <?php if($errors->has('price')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('price')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Prix Consigne:</label>
                        <input type="number" name="consigne_price">
                        <?php if($errors->has('consigne_price')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('consigne_price')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.appLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/super/create-client-price.blade.php ENDPATH**/ ?>