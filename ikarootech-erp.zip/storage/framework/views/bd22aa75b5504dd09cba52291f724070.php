<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env('COMPANIE_NAME')); ?> SCMS</title>
    <link rel="icon" href="/images/logo.png">
    <link href="toastr.css" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/css/dataTables.dataTables.min.css">
</head>

<body class="mx-20">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/2.0.8/js/dataTables.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <?php if(session('success')): ?>
        <script type="module">
            $(document).ready(function() {
                toastr.success("<?php echo e(session('success')); ?>")
            })
        </script>
    <?php elseif($errors->has('message')): ?>
        <script type="module">
            $(document).ready(function() {
                toastr.error("<?php echo e($errors->first('message')); ?>")
            })
        </script>
    <?php endif; ?>
    <header class="p-4">
        <div class="w-full flex justify-between">
            <img src="/images/logo.png" class="w-32 h-auto" alt="">
            <div class="text-center mt-2">
                <p>
                    <i class="fa-solid fa-user"></i>
                    <?php echo e(Auth::user()->email); ?>

                </p>
                <h2 class="text-large">Stargas Supply Chain Management System</h2>
                <h2 class="text-large">
                    Region: <?php echo e(strtoupper(Auth::user()->region)); ?>

                </h2>
                <h2 class="text-large">
                    Service: <?php echo e(Auth::user()->role); ?>

                </h2>
            </div>
            <div class=" mt-10 cursor-pointer text-center">
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit">
                        <i class="fa    -solid fa-right-from-bracket text-red-800 text-4xl"></i>
                        <p> deconnexion</p>
                    </button>
                </form>
            </div>
        </div>
        <nav class="mt-2 p-2 first-letter: w-full flex  gap-5 text-white primary rounded-md">
            <div> <a href="<?php echo e(route('bossDashboard')); ?>"><i class="fa-solid fa-home"></i> ACCUEIL</a></div>

            <div><a href="<?php echo e(route('showCiterneCon')); ?>">CITERNES</a></div>
            <div><a href="<?php echo e(route('closures.index')); ?>">PERIODES</a></div>
            <div class="dropdown cursor-pointer font-bold relative"> ETATS <i class="fa-solid fa-angle-down"></i>
                <div class="drop-items">


                    <div class="text-center elem"><a href="<?php echo e(route('historique-rel-con')); ?>">ETAT DES RELEVES</a>
                    </div>
                    <div class="text-center elem"><a href="<?php echo e(route('showReleveCon')); ?>">RECEPTION</a>
                    </div>
                    <div class="drop-2 elem"><a href="<?php echo e(route('showConHist')); ?>">ETAT DES PRODUCTION</a></div>
                    <div class="drop-2 elem">
                        <a href="<?php echo e(route('showVentesCon', ['type' => 'vente'])); ?>"> VENTES</a>
                    </div>
                    <div class="drop-2 elem">
                        <a href="<?php echo e(route('showVentesCon', ['type' => 'consigne'])); ?>"> CONSIGNES</a>
                    </div>

                    <div class="drop-2 elem"><a href="<?php echo e(route('broutes-list-con')); ?>">Bordereaux de Route</a>
                    </div>
                    <div class="drop-2 elem">
                        <a href="<?php echo e(route('showVentesCon', ['type' => 'versements'])); ?>"> VERSEMENTS</a>
                    </div>

                </div>
            </div>
            <div class="font-bold cursor-pointer dropdown relative">GENERER UN DOCUMENT PDF<i
                    class="fa-solid fa-angle-down"></i>
                <ul class="drop-items">

                    <li class="elem" id="activate-pdf-form">Etats des mouvements</li>
                    <li class="elem text-red-600" id="activate-new-sales-state-pdf-form">Etats des vente nouveau</li>
                    <li class="elem" id="activate-receives-pdf-form">Historique des receptions</li>
                    <li class="elem" id="activate-sales-state-pdf-form">Etats des Ventes</li>
                    <li class="elem" id="activate-versement-pdf-form">Historique des Versements</li>
                    <li class="elem" id="activate-releves-pdf-form">Historique des releves</li>
                    <li class="elem" id="activate-produce-pdf-form">Etats des ProductionS</li>

                </ul>
            </div>
            <div class="font-bold cursor-pointer dropdown relative">GENERER UN DOCUMENT EXCEL<i
                    class="fa-solid fa-angle-down"></i>
                <ul class="drop-items">

                    <li class="elem" id="activate-move-excels-form">Etats des
                        mouvements
                    </li>
                    <li class="elem" id="activate-receives-excel-form">Historique des receptions</li>
                    <li class="elem" id="activate-sales-state-excel-form">Etats des Ventes</li>
                    <li class="elem" id="activate-versement-excel-form">Historique des Versements</li>
                    <li class="elem" id="activate-releves-excel-form">Historique des releves</li>
                    <li class="elem" id="activate-produce-excel-form">Etats des ProductionS</li>

                </ul>
            </div>
            <div class="font-bold cursor-pointer dropdown relative">GERER CLIENTS<i class="fa-solid fa-angle-down"></i>
                <ul class="drop-items">

                    <!-- <li class="elem" id="activate-pdf-form">Etats des mouvements</li> -->
                    <li class="elem"><a href="<?php echo e(route('client-cats')); ?>">CATEGORIES CLIENTS</a></li>
                    <li class="elem"><a href="<?php echo e(route('list-clients')); ?>">CLIENTS</a></li>
                    <li class="elem"><a href="<?php echo e(route('client-price')); ?>">PRIX CATEGORIES</a></li>
                </ul>
            </div>
        </nav>
    </header>

   
    <!--FORMULAIRE GENERATION ETAT DES VENTES NOUVEAU-->

    <div id="new-sales-pdf-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF historique des ventes/consignes <span class="text-red-500"> Nouveau</span></h1>
                    <b class="close-modal">X </b>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" action="<?php echo e(route('new-sales-pdf')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart">
                        <?php if($errors->has('depart')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('depart')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin">
                        <?php if($errors->has('fin')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('fin')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Client :</label><br>

                        <select name="client" class="clients2" style="width: 100%" id="">

                            <option value="all" class="w-full">Tous</option>
                            <?php $__currentLoopData = $clientsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($client->id); ?>"><?php echo e($client->nom); ?> <?php echo e($client->prenom); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php if($errors->has('state')): ?>
                        <b class="text-red-500"><?php echo e($errors->first('state')); ?></b>
                    <?php endif; ?>
                    <div class="modal-champs">
                        <label for="">Type de Action</label>
                        <select name="sale" id="">

                            <option value="vente">vente</option>
                            <option value="consigne">consigne</option>

                        </select>
                        <?php if($errors->has('move')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('move')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Article:</label>
                        <select name="article" class="clients2" style="width: 100%" id="">
                            <?php $__currentLoopData = $articlesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($article->id); ?>">
                                    <?php echo e($article->type == 'accessoire' ? $article->title : $article->weight . ' kg'); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('move')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('move')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE DE GENERATION DE EXCEL-->
    <div id="move-excel-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un Fichier Excel</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('export-excelts')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">etat :</label><br>

                        <input type="radio" value="777" name="state"> GLOBAL
                        <input type="radio" value="0" name="state"> VIDES
                        <input type="radio" value="1" name="state"> PLEINES
                    </div>
                    <?php if($errors->has('state')): ?>
                        <span class="text-red-500"><?php echo e($errors->first('state')); ?></span>
                    <?php endif; ?>
                    <div class="modal-champs">
                        <label for="">Type de Movement</label>
                        <select name="move" id="">

                            <option value="1">entree</option>
                            <option value="0">sortie</option>
                            <option value="777">Global</option>

                        </select>
                        <?php if($errors->has('move')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('move')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="modal-champs">
                        <label for="">Service</label>
                        <select name="service" id="">

                            <option value="production">production</option>
                            <option value="magasin">magasin</option>
                            <option value="commercial">commmercial</option>

                        </select>
                        <?php if($errors->has('service')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('service')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Type de bouteille</label>
                        <select name="type" id="">

                            <option value="50">50KG</option>
                            <option value="12.5">12.5KG</option>
                            <option value="6">6KG</option>
                            <option value="777">accessiore</option>

                        </select>
                        <?php if($errors->has('type')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('type')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE DE GENERATION DE EXCEL RECEPTIONS-->
    <div id="recieves-excel-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF RECEPTIONS</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('receives_boss_excel')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Service:</label>
                        <select name="service" required>
                            <option value="magasin">Magasin</option>
                            <option value="production">Production</option>
                        </select>
                        <?php if($errors->has('service')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('service')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Citerne</label>
                        <select name="citerne" id="">
                            <?php $__currentLoopData = $mobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fix->id); ?>"><?php echo e($fix->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <option value="global"> Global</option>
                        </select>
                        <?php if($errors->has('citerne')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('citerne')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE GENERATION ETAT DES VENTES EN EXCEL-->

    <div id="sales-state-excel-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un EXCEL etats des ventes/consignes</h1>
                    <b class="close-modal">X </b>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" action="<?php echo e(route('boss_sale_state_excel')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart">
                        <?php if($errors->has('depart')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('depart')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin">
                        <?php if($errors->has('fin')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('fin')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Client :</label><br>

                        <input type="text" name="name">
                    </div>
                    <?php if($errors->has('state')): ?>
                        <b class="text-red-500"><?php echo e($errors->first('state')); ?></b>
                    <?php endif; ?>

                    <div class="modal-champs">
                        <label for="">Type de Action</label>
                        <select name="sale" id="">

                            <option value="vente">vente</option>
                            <option value="consigne">consigne</option>
                            <option value="accessoire">accessoire</option>

                        </select>
                        <?php if($errors->has('move')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('move')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE DE GENERATION PDF-->
    <div id="recieves-excel-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF RECEPTIONS</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('receives_boss_pdf')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Service:</label>
                        <select name="service" required>
                            <option value="magasin">Magasin</option>
                            <option value="production">Production</option>
                        </select>
                        <?php if($errors->has('service')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('service')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Citerne</label>
                        <select name="citerne" id="">
                            <?php $__currentLoopData = $mobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fix->id); ?>"><?php echo e($fix->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <option value="global"> Global</option>
                        </select>
                        <?php if($errors->has('citerne')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('citerne')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE GENERATION ETAT DES VERSEMENTS-->

    <div id="versement-excel-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un EXCEL historique des versements</h1>
                    <b class="close-modal">X </b>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" action="<?php echo e(route('boss_versementexcel')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart">
                        <?php if($errors->has('depart')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('depart')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin">
                        <?php if($errors->has('fin')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('fin')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">BANQUE :</label><br>

                        <select name="bank" id="">
                            <option value="AFB">AFB</option>
                            <option value="CCA">CCA</option>
                            <option value="CAISSE">CAISSE</option>
                            <option value="all">Tous</option>
                        </select>
                    </div>
                    <?php if($errors->has('bank')): ?>
                        <b class="text-red-500"><?php echo e($errors->first('bank')); ?></b>
                    <?php endif; ?>
                    <div class="modal-champs">
                        <label for="">service</label>
                        <select name="service" id="">
                            <option value="commercial">Commercial</option>

                        </select>
                        <?php if($errors->has('region')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('region')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE DE GENERATION DE PDF RElEVEES-->
    <div id="releves-excel-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un Excel RELEVES</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('releves_excel')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Citerne</label>
                        <select name="citerne" id="">
                            <?php $__currentLoopData = $fixe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fix->name); ?>"><?php echo e($fix->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="global"> Global</option>
                        </select>
                        <?php if($errors->has('citerne')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('citerne')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>

    <!--FORMULAIRE DE GENERATION DE EXCEL PRODUCTION-->
    <div id="produce-excel-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un Excel Production</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('genProdHistConExcel')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Citerne</label>
                        <select name="citerne" id="">
                            <?php $__currentLoopData = $fixe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fix->id); ?>"><?php echo e($fix->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="global"> Global</option>
                        </select>
                        <?php if($errors->has('citerne')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('citerne')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>

    <!--FORMULAIRE DE GENERATION DE PDF PRODUCTION-->
    <div id="produce-pdf-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF Production</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('genProdHistCon')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Citerne</label>
                        <select name="citerne" id="">
                            <?php $__currentLoopData = $fixe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fix->id); ?>"><?php echo e($fix->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="global"> Global</option>
                        </select>
                        <?php if($errors->has('citerne')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('citerne')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>

    <!--FORMULAIRE DE GENERATION DE PDF RElEVEES-->
    <div id="releves-pdf-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF RELEVES</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('releves_pdf')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Citerne</label>
                        <select name="citerne" id="">
                            <?php $__currentLoopData = $fixe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fix->name); ?>"><?php echo e($fix->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="global"> Global</option>
                        </select>
                        <?php if($errors->has('citerne')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('citerne')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE DE GENERATION DE PDF RECEPTIONS-->
    <div id="recieves-pdf-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF RECEPTIONS</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('receives_boss_pdf')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Service:</label>
                        <select name="service" required>
                            <option value="magasin">Magasin</option>
                            <option value="production">Production</option>
                        </select>
                        <?php if($errors->has('service')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('service')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Citerne</label>
                        <select name="citerne" id="">
                            <?php $__currentLoopData = $mobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fix->id); ?>"><?php echo e($fix->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <option value="global"> Global</option>
                        </select>
                        <?php if($errors->has('citerne')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('citerne')); ?></span>
                        <?php endif; ?>
                    </div>



                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE DE GENERATION DE PDF-->
    <div id="pdf-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF</h1>
                    <span class="close-modal">X </span>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form method="POST" action="<?php echo e(route('pdfController')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart" required>
                        <?php if($errors->has('depart')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('depart')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin" required>
                        <?php if($errors->has('fin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('fin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Destination (optionnel) :</label><br>
                            
                        <select name="origin" >
                            <option value="">Toutes</option>
                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value=<?php echo e($region->region); ?>><?php echo e($region->region); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="modal-champs">
                        <label for="">etat :</label><br>

                        <input type="radio" value="1" name="state"> pleine
                        <input type="radio" value="0" name="state">vide
                        <input type="radio" value="777" name="state">accessoire
                    </div>
                    <?php if($errors->has('state')): ?>
                        <span class="text-red-500"><?php echo e($errors->first('state')); ?></span>
                    <?php endif; ?>
                    <div class="modal-champs">
                        <label for="">Type de Movement</label>
                        <select name="move" id="">

                            <option value="1">entree</option>
                            <option value="0">sortie</option>
                            <option value="777">Global</option>

                        </select>
                        <?php if($errors->has('move')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('move')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="modal-champs">
                        <label for="">Service</label>
                        <select name="service" id="">

                            <option value="production">production</option>
                            <option value="magasin">magasin</option>
                            <option value="commercial">commmercial</option>

                        </select>
                        <?php if($errors->has('service')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('service')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Type de bouteille</label>
                        <select name="type" id="">

                            <option value="50">50KG</option>
                            <option value="12.5">12.5KG</option>
                            <option value="6">6KG</option>
                            <option value="777">accessiore</option>

                        </select>
                        <?php if($errors->has('type')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('type')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>

    <!--FORMULAIRE GENERATION ETAT DES VERSEMENTS-->

    <div id="versement-pdf-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF historique des versements</h1>
                    <b class="close-modal">X </b>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" action="<?php echo e(route('versementPdf')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart">
                        <?php if($errors->has('depart')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('depart')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin">
                        <?php if($errors->has('fin')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('fin')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Client :</label><br>

                        <select name="client" class="clients2" style="width: 100%" id="">

                            <option value="all" class="w-full">Tous</option>
                            <?php $__currentLoopData = $clientsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($client->id); ?>"><?php echo e($client->nom); ?> <?php echo e($client->prenom); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="modal-champs">
                        <label for="">BANQUE :</label><br>

                        <select name="bank" id="">
                            <option value="AFB">AFB</option>
                            <option value="CCA">CCA</option>
                            <option value="CAISSE">CAISSE</option>
                            <option value="all">Tous</option>
                        </select>
                    </div>
                    <?php if($errors->has('bank')): ?>
                        <b class="text-red-500"><?php echo e($errors->first('bank')); ?></b>
                    <?php endif; ?>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
    <!--FORMULAIRE GENERATION ETAT DES VENTES-->

    <div id="sales-state-pdf-form" class="modals">
        <center>

            <div class="modal-active">
                <div class="modal-head">
                    <h1>Generer un PDF etats des ventes/consignes</h1>
                    <b class="close-modal">X </b>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" action="<?php echo e(route('boss_sale_state_pdf')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Du:</label>
                        <input type="date" name="depart">
                        <?php if($errors->has('depart')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('depart')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Au:</label>
                        <input type="date" name="fin">
                        <?php if($errors->has('fin')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('fin')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Client :</label><br>

                        <input type="text" name="name">
                    </div>
                    <?php if($errors->has('state')): ?>
                        <b class="text-red-500"><?php echo e($errors->first('state')); ?></b>
                    <?php endif; ?>

                    <div class="modal-champs">
                        <label for="">Type de Action</label>
                        <select name="sale" id="">

                            <option value="vente">vente</option>
                            <option value="consigne">consigne</option>
                            <option value="accessoire">accessoire</option>

                        </select>
                        <?php if($errors->has('move')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('move')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>

    <div class="w-full overflow-x-scroll  h-full ">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="mt-10 w-full secondary flex justify-between p-4 text-white rounded-md">
        <div>
            <a href="">Contacter</a>
            <a href="">Aide</a>
            <a href="">Mention Legal</a>
        </div>
        <p>&copy; 2024</p>
    </footer>
    <script type="module">
        $(function() {
            $('table').DataTable();
            
        
        $(".clients2").select2()
        //ACTION ENTRY ON MODAL GPL
            //ACTION NEW SALES STATE PDF FORM
            $("#activate-new-sales-state-pdf-form").on("click", function(e) {
                e.preventDefault()
                if ($("#new-sales-pdf-form").hasClass("modals")) {
                    $("#new-sales-pdf-form").addClass("modals-active")

                    $("#new-sales-pdf-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#new-sales-pdf-form").hasClass("modals-active")) {
                    $("#new-sales-pdf-form").addClass("modals")
                    $("#new-sales-pdf-form").removeClass("modals-active")
                }
            })
            
            //ACTION generate excel movements
            $("#activate-move-excels-form").on("click", function(e) {
                e.preventDefault()
                if ($("#move-excel-form").hasClass("modals")) {
                    $("#move-excel-form").addClass("modals-active")

                    $("#move-excel-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#move-excel-form").hasClass("modals-active")) {
                    $("#move-excel-form").addClass("modals")
                    $("#move-excel-form").removeClass("modals-active")
                }
            })
            //ACTION generate excel receives 
            $("#activate-receives-excel-form").on("click", function(e) {
                e.preventDefault()
                if ($("#recieves-excel-form").hasClass("modals")) {
                    $("#recieves-excel-form").addClass("modals-active")

                    $("#recieves-excel-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#recieves-excel-form").hasClass("modals-active")) {
                    $("#recieves-excel-form").addClass("modals")
                    $("#recieves-excel-form").removeClass("modals-active")
                }
            })



            //ACTION GENERER EXCEL VENTES

            $("#activate-sales-state-excel-form").on("click", function(e) {
                e.preventDefault()
                if ($("#sales-state-excel-form").hasClass("modals")) {
                    $("#sales-state-excel-form").addClass("modals-active")

                    $("#sales-state-excel-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#sales-state-excel-form").hasClass("modals-active")) {
                    $("#sales-state-excel-form").addClass("modals")
                    $("#sales-state-excel-form").removeClass("modals-active")
                }
            })
            //ACTION versement historique Excel
            $("#activate-versement-excel-form").on("click", function(e) {
                e.preventDefault()
                if ($("#versement-excel-form").hasClass("modals")) {
                    $("#versement-excel-form").addClass("modals-active");
                    $("#versement-excel-form").removeClass("modals");
                }

                $(".close-modal").on("click", function(e) {
                    e.preventDefault()
                    if ($("#versement-excel-form").hasClass("modals-active")) {
                        $("#versement-excel-form").addClass("modals");
                        $("#versement-excel-form").removeClass("modals-active");
                    }
                })
            })
            //ACTION generate excel releves 
            $("#activate-releves-excel-form").on("click", function(e) {
                e.preventDefault()
                if ($("#releves-excel-form").hasClass("modals")) {
                    $("#releves-excel-form").addClass("modals-active")

                    $("#releves-excel-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#releves-excel-form").hasClass("modals-active")) {
                    $("#releves-excel-form").addClass("modals")
                    $("#releves-excel-form").removeClass("modals-active")
                }
            })
            //ACTION generate pdf produce
            $("#activate-produce-excel-form").on("click", function(e) {
                e.preventDefault()
                if ($("#produce-excel-form").hasClass("modals")) {
                    $("#produce-excel-form").addClass("modals-active")

                    $("#produce-excel-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#produce-excel-form").hasClass("modals-active")) {
                    $("#produce-excel-form").addClass("modals")
                    $("#produce-excel-form").removeClass("modals-active")
                }
            })
            //ACTION generate pdf produce
            $("#activate-produce-pdf-form").on("click", function(e) {
                e.preventDefault()
                if ($("#produce-pdf-form").hasClass("modals")) {
                    $("#produce-pdf-form").addClass("modals-active")

                    $("#produce-pdf-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#produce-pdf-form").hasClass("modals-active")) {
                    $("#produce-pdf-form").addClass("modals")
                    $("#produce-pdf-form").removeClass("modals-active")
                }
            })
            //ACTION generate pdf releves 
            $("#activate-releves-pdf-form").on("click", function(e) {
                e.preventDefault()
                if ($("#releves-pdf-form").hasClass("modals")) {
                    $("#releves-pdf-form").addClass("modals-active")

                    $("#releves-pdf-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#releves-pdf-form").hasClass("modals-active")) {
                    $("#releves-pdf-form").addClass("modals")
                    $("#releves-pdf-form").removeClass("modals-active")
                }
            })
            //ACTIon GENERATE PDF
            $("#activate-pdf-form").on("click", function(e) {
                e.preventDefault()
                if ($("#pdf-form").hasClass("modals")) {
                    $("#pdf-form").addClass("modals-active");
                    $("#pdf-form").removeClass("modals");
                }
            })
            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#pdf-form").hasClass("modals-active")) {
                    $("#pdf-form").addClass("modals");
                    $("#pdf-form").removeClass("modals-active");
                }
            })

            //ACTION generate pdf receives 
            $("#activate-receives-pdf-form").on("click", function(e) {
                e.preventDefault()
                if ($("#recieves-pdf-form").hasClass("modals")) {
                    $("#recieves-pdf-form").addClass("modals-active")

                    $("#recieves-pdf-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#recieves-pdf-form").hasClass("modals-active")) {
                    $("#recieves-pdf-form").addClass("modals")
                    $("#recieves-pdf-form").removeClass("modals-active")
                }
            })
            $("#activate-sales-state-pdf-form").on("click", function(e) {
                e.preventDefault()
                if ($("#sales-state-pdf-form").hasClass("modals")) {
                    $("#sales-state-pdf-form").addClass("modals-active")

                    $("#sales-state-pdf-form").removeClass("modals")
                }
            })

            $(".close-modal").on("click", function(e) {
                e.preventDefault()
                if ($("#sales-state-pdf-form").hasClass("modals-active")) {
                    $("#sales-state-pdf-form").addClass("modals")
                    $("#sales-state-pdf-form").removeClass("modals-active")
                }
            }) //ACTION versement historique
            $("#activate-versement-pdf-form").on("click", function(e) {
                e.preventDefault()
                if ($("#versement-pdf-form").hasClass("modals")) {
                    $("#versement-pdf-form").addClass("modals-active");
                    $("#versement-pdf-form").removeClass("modals");
                }

                $(".close-modal").on("click", function(e) {
                    e.preventDefault()
                    if ($("#versement-pdf-form").hasClass("modals-active")) {
                        $("#versement-pdf-form").addClass("modals");
                        $("#versement-pdf-form").removeClass("modals-active");
                    }
                })
            })



        })
    </script>
</body>

</html>
<?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/Layouts/controllerLayout.blade.php ENDPATH**/ ?>