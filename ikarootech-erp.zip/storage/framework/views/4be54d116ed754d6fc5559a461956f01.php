<?php $__env->startSection('content'); ?>
    <center>
        <h1 class="p-2 mt-5 font-bold text-2xl">Historique des Versements

        </h1>
        <div class=" flex w-full gap-3">
            <!-- The whole future lies in uncertainty: live immediately. - Seneca -->

            <table class="history scroll mt-10 w-1/2 border-2 border-collapse border-gray-400 text-center ">
                <thead class="p-3 bg-gray-500 text-white">
                    <td colspan="6" class="text-center">
                        <?php echo e(env('COMPANIE_BANK_1')); ?>

                    </td>
                    <tr>
                        <td>
                            date
                        </td>
                        <td>
                            GPL
                        </td>
                        <td>
                            Consigne
                        </td>
                        <td>
                            Montant Versee
                        </td>
                        <td>
                            Numerode bordereau
                        </td>
                        <td>commentaire</td>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:text-white hover:bg-blue-400 hover:cursor-pointer">
                            <td><?php echo e($vente->created_at); ?></td>
                            <td>
                                <?php echo e($vente->montant_gpl); ?>

                            </td>
                            <td>
                                <?php echo e($vente->montant_consigne); ?>

                            </td>
                            <td>
                                <?php echo e($vente->montant_gpl + $vente->montant_consigne); ?>

                            </td>
                            <td>
                                <?php echo e($vente->bordereau); ?>

                            </td>
                            <td> <?php echo e($vente->commentaire); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <table class="history scroll mt-10 w-1/2 border-2 border-collapse border-gray-400 text-center ">
                <thead class="p-3 bg-gray-500 text-white">
                    <td colspan="6" class="text-center">
                        <?php echo e(env('COMPANIE_BANK_2')); ?>

                    </td>
                    <tr>
                        <td>date</td>
                        <td>
                            GPL
                        </td>
                        <td>
                            Consigne

                        </td>
                        <td>
                            Montant Versee
                        </td>

                        <td>
                            Numerode bordereau
                        </td>
                        <td>
                            commentaire
                        </td>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $ventes2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:text-white hover:bg-blue-400 hover:cursor-pointer">
                            <td><?php echo e($vente->created_at); ?></td>
                            <td>
                                <?php echo e($vente->montant_gpl); ?>

                            </td>
                            <td>
                                <?php echo e($vente->montant_consigne); ?>

                            </td>
                            <td>
                                <?php echo e($vente->montant_gpl + $vente->montant_consigne); ?>

                            </td>
                            <td>
                                <?php echo e($vente->bordereau); ?>

                            </td>
                            <td>
                                <?php echo e($vente->commentaire); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div>

            <table class="history scroll mt-10 w-1/2 border-2 border-collapse border-gray-400 text-center ">
                <thead class="p-3 bg-gray-500 text-white">
                    <td colspan="6" class="text-center">
                        CAISSE
                    </td>
                    <tr>
                        <td>date</td>
                        <td>
                            GPL
                        </td>
                        <td>
                            Consigne

                        </td>
                        <td>
                            Montant Versee
                        </td>

                        <td>
                            Numerode bordereau
                        </td>
                        <td>
                            commentaire
                        </td>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $ventes3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:text-white hover:bg-blue-400 hover:cursor-pointer">
                            <td><?php echo e($vente->created_at); ?></td>
                            <td>
                                <?php echo e($vente->montant_gpl); ?>

                            </td>
                            <td>
                                <?php echo e($vente->montant_consigne); ?>

                            </td>
                            <td>
                                <?php echo e($vente->montant_gpl + $vente->montant_consigne); ?>

                            </td>
                            <td>
                                <?php echo e($vente->bordereau); ?>

                            </td>
                            <td>
                                <?php echo e($vente->commentaire); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.controllerLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/controller/historique-versements.blade.php ENDPATH**/ ?>