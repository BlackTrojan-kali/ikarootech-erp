<?php $__env->startSection('content'); ?>
<div class="p-6">
    <div class="w-full flex justify-between">
    <h1 class="text-2xl font-bold mb-4">Liste des fermetures</h1>
    <a href=<?php echo e(route("closures.create")); ?> class="bg-green-500 px-4 py-2 w-[100px] text-white text-center">
    Creer
</a>   
</div>
    <table class="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
        <thead class="bg-gray-200">
            <tr>
                <th class="py-2 px-4 border-b text-left">Region</th>
                <th class="py-2 px-4 border-b text-left">Date de début</th>
                <th class="py-2 px-4 border-b text-left">Date de fin</th>
                <th class="py-2 px-4 border-b text-left">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $closures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $closure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-2 px-4 border-b"><?php echo e($closure->region); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($closure->starting_date); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($closure->ending_date); ?></td>
                    <td class="py-2 px-4 border-b">
                        <a href="<?php echo e(route('closures.edit', $closure->id)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded">
                            Modifier
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.controllerLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/closures/index.blade.php ENDPATH**/ ?>