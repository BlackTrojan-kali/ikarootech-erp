<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Liste de Prix</title>
    <style>
        /* La police DejaVu Sans est utilisée pour s'assurer que Dompdf gère correctement les caractères spéciaux (comme les accents) */
        body { 
            font-family: DejaVu Sans, sans-serif; 
            font-size: 10pt;
        }
        h1, h2 { 
            text-align: center; 
            color: #2c3e50; /* Couleur sombre pour le professionnalisme */
        }
        h1 {
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }
        th, td {
            border: 1px solid #bdc3c7;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #ecf0f1;
            color: #2c3e50;
            font-weight: bold;
            text-align: center;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .filter-info {
            margin-top: 10px;
            text-align: center;
            font-weight: 600;
        }
        .footer {
            position: fixed;
            bottom: -30px;
            left: 0px;
            right: 0px;
            height: 50px;
            font-size: 8pt;
            text-align: center;
            line-height: 35px;
            border-top: 1px solid #bdc3c7;
        }
    </style>
</head>
<body>

    <h1>LISTE DES PRIX SPÉCIFIQUES</h1>

    <div class="filter-info">
        <h2>Catégorie Client : <?php echo e($categoryName); ?></h2>

        <?php if($filterArticle): ?>
            <p>Article Filtré : <?php echo e($filterArticle); ?></p>
        <?php else: ?>
            <p>Affichage de tous les articles pour cette catégorie.</p>
        <?php endif; ?>
    </div>

    <table>
        <thead>
            <tr>
                <th>Article (Type)</th>
                <th>Poids</th>
                <th>Région</th>
                <th>Prix GPL (Unité)</th>
                <th>Prix Consigne</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        
                        <?php if($price->article->type == 'accessoire'): ?>
                            <?php echo e($price->article->title); ?>

                        <?php else: ?>
                            <?php echo e($price->article->type); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        
                        <?php if($price->article->type != 'accessoire'): ?>
                            <?php echo e($price->article->weight . ' KG'); ?>

                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($price->region); ?></td>
                    
                    
                    <td><?php echo e(number_format($price->unite_price, 0, ',', ' ')); ?> XAF</td>
                    <td><?php echo e(number_format($price->consigne_price, 0, ',', ' ')); ?> XAF</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer">
        Document généré par le système le : <?php echo e(now()->format('d/m/Y H:i:s')); ?>

    </div>

</body>
</html><?php /**PATH C:\Users\blacktrojan\Documents\GitHub\ikarootech-erp\resources\views/controller/price_list.blade.php ENDPATH**/ ?>