<?php $__env->startSection("content"); ?>
<?php
$name = "stargaz"
?>
<center class="w-full p-4">
    <h1 class="mb-3 text-xl font-bold">Enregistrer un nouveau stock</h1>
    <form action="<?php echo e(route('post_stock')); ?>" method="POST" class="p-4 border border-blue-400 rounded-lg w-5/12">
        <?php echo csrf_field(); ?>
      
        <div class="champs">
            <label for="">Article</label>
            <select name="article"  class="w-full p-3 font-bold" id="">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($article->id); ?>">
<?php if($article->title == "stargas"): ?>
    <?php if($article->state == 1): ?>
            <?php echo e($article->weight." ".$article->unity." pleine"); ?>

            <?php else: ?>
            <?php echo e($article->weight." ".$article->unity." videe"); ?>

    <?php endif; ?>
    <?php else: ?>
    <?php echo e($article->title); ?>

<?php endif; ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has("article")): ?>
                    <p class="text-red-500"><?php echo e($errors->first('article')); ?></p>
                <?php endif; ?>
            </select>
        </div>
        <div class="champs">
            <label for="">Region</label>
            <select name="region"  class="w-full p-3 font-bold" id="">
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($region->region); ?>">
                        <?php echo e($region->region); ?>


                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has("region")): ?>
                    <p class="text-red-500"><?php echo e($errors->first('region')); ?></p>
                <?php endif; ?>
            </select>
        </div>
        <br>
        <div class="w-full flex justify-end">
            <button class="text-white font-bold bg-blue-400 p-2" type="submit">Enregistrer </button>
        </div>
    </form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/super/add_stock.blade.php ENDPATH**/ ?>