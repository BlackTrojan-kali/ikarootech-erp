<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Stargas SCMS</title>
    <link rel="icon" href="/images/logo.png">
    <link href="toastr.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body class="">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        @font-face {
            font-family: 'Riot';
            src: url(<?php echo e(storage_path('/fonts/ProtestRiot-Regular.ttf')); ?>) format("truetype");
            font-weight: 400;
            font-style: normal;
        }

        body {
            font-family: "Riot";
            padding: 5px;
        }

        table {
            border: 1px solid white;
            border-collapse: collapse;
        }

        .table-1,
        .table-2,
        .table-3 {
            border: 2px solid black;

        }

        .table-1 th,
        .table-2 th,
        .table-3 th {
            font-size: 0.8rem;

        }

        .table-1 th,
        .table-1 tr,
        .table-1 td,
        .table-2 th,
        .table-2 tr,
        .table-2 td,
        .table-3 th,
        .table-3 tr,
        .table-3 td {
            border: 1px solid black;
            padding: 4px;

        }

        .logo-section {
            position: absolute;
            top: 2px;
        }

        .head-color {
            background-color: burlywood;
            padding: 20px;
        }
    </style>
    <br>
    <br><br>
    <br>
    <br><br><br>
    <br><br>

    <div class="logo-section">
        <img src="<?php echo e(public_path('images/logo.png')); ?>"
            width="100px">
        <p>
            <b><?php echo e(env('COMPANIE_NAME')); ?></b><br>
            <b>B.P:</b><?php echo e(env('COMPANIE_ADDRESS')); ?> <br>
            <b>Tél:</b><?php echo e(env('COMPANIE_CANTACT_1')); ?> <br>
            <b>Email:</b> <?php echo e(env('COMPANIE_EMAIL_1')); ?> <br>
        </p>
    </div>
    <center>
        <h3><?php echo e(strtoupper(Auth::user()->role)); ?> :<?php echo e(strtoupper(Auth::user()->region)); ?> </h3 <h4> FICHE DE VERSEMENTS
            GLOBAL</h4>

    </center>
    <center><u>
            <h1>AFB BANK</h1>
        </u></center>
    <table class="table-1">
        <thead>
            <th colspan="3">VENTES Associees</th>
            <th colspan="6">VERSEMENTS AFB</th>
            <tr>
                <th><b>DATES</b></th>
                <th><b>Factures Associées</b></th>
                <th><b>Total Factures</b></th>
                <th><b>GPL</b></th>
                <th><b>Consigne</b></th>
                <th><b>Total</b></th>
                <th><b>Commentaire</b></th>
                <th><b>Total Commentaire</b></th>
                <th><b>Écart</b></th>
            </tr>
        </thead>

        <?php $total1 = 0;
        $total_gpl1 = 0;
        $total_consigne1 = 0;
        $total_com1 = 0; 
        
        $total_ecart1 = 0;
        $total_invoices1 = 0;
        ?>

        <tbody>
            <?php $__currentLoopData = $afb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-blue-400 hover:text-white hover:cursor-pointer">
                    <td>
                        <?php echo e($data->created_at); ?>

                    </td>

                    
                    <td>
                        <ul>
                            <?php $total_factures= 0?>
                            <?php $__currentLoopData = $data->Invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>Facture N°: <?php echo e($facture->region."-".$facture->id."/".$facture->client->nom." ".$facture->client->prenom); ?> (<?php echo e($facture->total_price); ?>)</li>
                                <?php $total_factures += $facture->total_price;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td><?php echo e($total_factures); ?></td>
                    
                    
                    <td>
                        <?php echo e($data->montant_gpl); ?>

                    </td>
                    <td><?php echo e($data->montant_consigne); ?></td>

                    <?php
                    $versement_total = $data->montant_gpl + $data->montant_consigne;
                    $total1 += $versement_total;
                    $total_gpl1 += $data->montant_gpl;
                    $total_consigne1 += $data->montant_consigne;
                    $total_com1 += $data->montantcom;
                    
                    // NOUVEAU CALCUL DE L'ÉCART
                    $versements_complets = $versement_total + $data->montantcom;
                    $ecart = $versements_complets - $total_factures;
                    
                    $total_ecart1 += $ecart;
                    $total_invoices1 +=$total_factures;
                    ?>
                    
                    <td><?php echo e($versement_total); ?></td>
                    <td><?php echo e($data->commentaire); ?></td>
                    <td><?php echo e($data->montantcom); ?></td>
                    <td style="<?php echo e($ecart < 0 ? 'color: red;' : 'color: green;'); ?>">
                        <?php echo e($ecart); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr style="font-weight: bold;">
                <td>/</td>
                <td>/</td>
                <td><?php echo e(number_format($total_invoices1, 2, ',', ' ')); ?></td>
                <td><?php echo e($total_gpl1); ?></td>
                <td><?php echo e($total_consigne1); ?></td>
                <td><?php echo e(number_format($total1, 2, ',', ' ')); ?></td>
                <td>/</td>
                <td><?php echo e(number_format($total_com1, 2, ',', ' ')); ?></td>
                <td><?php echo e(number_format($total_ecart1, 2, ',', ' ')); ?></td>
            </tr>
        </tbody>
    </table>
    
    <br>
    
    <center>
        <u>
            <h1>CCA BANK</h1>
        </u>
    </center>

    <table class="table-2">
        <thead>
            <th colspan="3">VENTES Associees</th>
            <th colspan="6">VERSEMENTS CCA</th>
            <tr>
                <th><b>DATES</b></th>
                <th><b>Factures Associées</b></th>
                <th><b>Total Factures</b></th>
                <th><b>GPL</b></th>
                <th><b>Consigne</b></th>
                <th><b>Total</b></th>
                <th><b>Commentaire</b></th>
                <th><b>Total Commentaire</b></th>
                <th><b>Écart</b></th>
            </tr>
        </thead>
        <?php $total2 = 0; // Renommé pour éviter de mélanger avec $total1
        $total_gpl2 = 0; // Renommé
        $total_consigne2 = 0; // Renommé
        $total_com2 = 0;

        $total_ecart2 = 0;
        $total_invoices2 = 0;
          ?>
        
        <tbody>
            <?php $__currentLoopData = $cca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-blue-400 border-1 hover:text-white hover:cursor-pointer">
                    <td>
                        <?php echo e($data->created_at); ?>

                    </td>
                    
                    
                    <td>
                        <ul>
                            <?php $total_factures= 0?>
                            <?php $__currentLoopData = $data->Invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>Facture N°: <?php echo e($facture->region."-".$facture->id."/".$facture->client->nom." ".$facture->client->prenom); ?> (<?php echo e($facture->total_price); ?>)</li>
                            <?php $total_factures += $facture->total_price;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td><?php echo e($total_factures); ?></td>

                    
                    <td>
                        <?php echo e($data->montant_gpl); ?>

                    </td>
                    <td><?php echo e($data->montant_consigne); ?></td>
                    
                    <?php
                    $versement_total = $data->montant_gpl + $data->montant_consigne;
                    $total2 += $versement_total;
                    $total_gpl2 += $data->montant_gpl;
                    $total_consigne2 += $data->montant_consigne;
                    $total_com2 += $data->montantcom;
                    
                    // NOUVEAU CALCUL DE L'ÉCART
                    $versements_complets = $versement_total + $data->montantcom;
                    $ecart = $versements_complets - $total_factures;
                    
                    $total_ecart2 += $ecart;
                    $total_invoices2 +=$total_factures;
                    ?>
                    
                    <td><?php echo e($versement_total); ?></td>
                    <td><?php echo e($data->commentaire); ?></td>
                    <td><?php echo e($data->montantcom); ?></td>
                    <td style="<?php echo e($ecart < 0 ? 'color: red;' : 'color: green;'); ?>">
                        <?php echo e($ecart); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr style="font-weight: bold;">
                <td>/</td>
                <td>/</td>
                <td><?php echo e(number_format($total_invoices2, 2, ',', ' ')); ?></td>
                <td><?php echo e($total_gpl2); ?></td>
                <td><?php echo e($total_consigne2); ?></td>
                <td><?php echo e(number_format($total2, 2, ',', ' ')); ?></td>
                <td>/</td>
                <td><?php echo e(number_format($total_com2, 2, ',', ' ')); ?></td>
                <td><?php echo e(number_format($total_ecart2, 2, ',', ' ')); ?></td>
            </tr>
        </tbody>
    </table>

    <center>
        <u>
            <h1>CAISSE</h1>
        </u>
    </center>
    <table class="table-3">
        <thead>
            <th colspan="3">VENTES Associees</th>
            <th colspan="6">VERSEMENTS CAISSE</th>
            <tr>
                <th><b>DATES</b></th>
                <th><b>Factures Associées</b></th>
                <th><b>Total Factures</b></th>
                <th><b>GPL</b></th>
                <th><b>Consigne</b></th>
                <th><b>Total</b></th>
                <th><b>Commentaire</b></th>
                <th><b>Total Commentaire</b></th>
                <th><b>Écart</b></th>
            </tr>
        </thead>
        <?php $total3 = 0; // Renommé
        $total_gpl3 = 0; // Renommé
        $total_consigne3 = 0; // Renommé
        $total_com3 = 0;
        
        $total_ecart3 = 0;
        $total_invoices3 = 0;
          ?>
        <tbody>
            <?php $__currentLoopData = $caisse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-blue-400 hover:text-white hover:cursor-pointer">
                    <td>
                        <?php echo e($data->created_at); ?>

                    </td>

                    
                    <td>
                        <ul>
                            <?php $total_factures= 0?>
                            <?php $__currentLoopData = $data->Invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>Facture N°: <?php echo e($facture->region."-".$facture->id."/".$facture->client->nom." ".$facture->client->prenom); ?> (<?php echo e($facture->total_price); ?>)</li>
                            <?php $total_factures += $facture->total_price;?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td><?php echo e($total_factures); ?></td>
                    
                    
                    <td>
                        <?php echo e($data->montant_gpl); ?>

                    </td>
                    <td><?php echo e($data->montant_consigne); ?></td>
                    
                    <?php
                    $versement_total = $data->montant_gpl + $data->montant_consigne;
                    $total3 += $versement_total;
                    $total_gpl3 += $data->montant_gpl;
                    $total_consigne3 += $data->montant_consigne;
                    $total_com3 += $data->montantcom;
                    
                    // NOUVEAU CALCUL DE L'ÉCART
                    $versements_complets = $versement_total + $data->montantcom;
                    $ecart = $versements_complets - $total_factures;
                    
                    $total_ecart3 += $ecart;
                    $total_invoices3 +=$total_factures;
                    ?>
                    
                    <td><?php echo e($versement_total); ?></td>
                    <td><?php echo e($data->commentaire); ?></td>
                    <td><?php echo e($data->montantcom); ?></td> 
                    <td style="<?php echo e($ecart < 0 ? 'color: red;' : 'color: green;'); ?>">
                        <?php echo e($ecart); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr style="font-weight: bold;">
                <td>/</td>
                <td>/</td>
                <td><?php echo e(number_format($total_invoices3, 2, ',', ' ')); ?></td>
                <td><?php echo e($total_gpl3); ?></td>
                <td><?php echo e($total_consigne3); ?></td>
                <td><?php echo e(number_format($total3, 2, ',', ' ')); ?></td>
                <td>/</td>
                <td><?php echo e(number_format($total_com3, 2, ',', ' ')); ?></td>
                <td><?php echo e(number_format($total_ecart3, 2, ',', ' ')); ?></td>
            </tr>
        </tbody>
    </table>
</body>

</html><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/versementPdfAll.blade.php ENDPATH**/ ?>