<?php $__env->startSection('content'); ?>
    <div class="w-full">
        <center>

            <div class="w-6/12 border-2 border-gray-300">
                <div class="modal-head">
                    <h1>Creer une nouvelle categorie client</h1>
                    <span><a href="<?php echo e(route("client-cats")); ?>">X</a></span>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" class="p-2" action="<?php echo e(route('store-client-cat')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Nom:</label>
                        <input type="text" name="name">
                        <?php if($errors->has('name')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('name')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.controllerLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/controller/create_client_cat.blade.php ENDPATH**/ ?>