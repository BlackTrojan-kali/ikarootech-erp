<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env('COMPANIE_NAME')); ?> SMS - Login</title>
    <link rel="icon" href="/images/logo.png">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>

    
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
</head>

<body class="secondary flex items-center justify-center min-h-screen p-4">

    <main class="w-full max-w-md mx-auto"> 

        
        <div class="bg-black/10 p-4 md:px-8 md:py-4 flex justify-between items-center rounded-t-md">
            <div class="rounded-md">
                <center>
                <img src="/images/logo.png" class="w-24" alt="Logo de <?php echo e(env('COMPANIE_NAME')); ?>" aria-label="Logo de l'entreprise">
                </center>
            </div>
        </div>

        
        <div class="box p-4 rounded-b-md font-bold text-center general bg-white shadow-md shadow-white/60 mb-8">
            <h2>Bienvenue sur <?php echo e(env('COMPANIE_NAME')); ?> Supply Chain Management System</h2>
        </div>

        
        <div class="bg-white rounded-md p-6 shadow-lg"> 
            <form action="<?php echo e(route('authenticate')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="champs mb-4"> 
                    <label for="email_login">Login:</label> 
                    <input type="email" id="email_login" name="email" class="w-full h-9 mt-2 bg-gray-400/25 p-2 mb-2 rounded-md" aria-label="Votre adresse e-mail">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                        <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="champs mb-6"> 
                    <label for="password_login">Mot de passe:</label> 
                    <input type="password" id="password_login" name="password" class="w-full h-9 mt-2 bg-gray-400/25 p-2 mb-2 rounded-md" aria-label="Votre mot de passe">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="mt-4 primary p-3 w-full rounded-md text-white font-semibold hover:opacity-90 transition-opacity">S'identifier</button> 
            </form>
        </div>
<br><br><br>
    </main>

    
    <footer class="w-full absolute bottom-0 left-0 ternary text-white p-4 text-end">
        <p>&copy; Tous droits réservés à <?php echo e(env('COMPANIE_NAME')); ?></p>
    </footer>

    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    
    <?php if($errors->has('warning')): ?>
        <script>
            $(document).ready(function() {
                toastr.warning("<?php echo e($errors->first('warning')); ?>", "Avertissement")
            })
        </script>
    <?php elseif(session('success')): ?>
        <script>
            $(document).ready(function() {
                toastr.success("<?php echo e(session('success')); ?>", "Succès")
            })
        </script>
    <?php elseif(session('error')): ?>
        <script>
            $(document).ready(function() {
                toastr.error("<?php echo e(session('error')); ?>", "Erreur")
            })
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/Auth/login.blade.php ENDPATH**/ ?>