<?php $__env->startSection("content"); ?>
<?php
$name = "stargaz"
?>
<center class="w-full p-4">
    <h1 class="mb-3 text-xl font-bold">Enregistrer une nouvelle famille produit</h1>
    <form action="<?php echo e(route("insertFamily")); ?>" method="POST" class="p-4 border border-blue-400 rounded-lg w-5/12">
        <?php echo csrf_field(); ?>
      
        <div class="champs">
            <label for="name">Nom:</label>
            <input type="text" name="name" required>
            <?php if($errors->has("name")): ?>
                <p class="text-red-500"><?php echo e($errors->first('name')); ?></p>
            <?php endif; ?>
        </div>
        <br>
        <div class="w-full flex justify-end">
            <button class="text-white font-bold bg-blue-400 p-2" type="submit">Enregistrer </button>
        </div>
    </form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/super/add_family.blade.php ENDPATH**/ ?>