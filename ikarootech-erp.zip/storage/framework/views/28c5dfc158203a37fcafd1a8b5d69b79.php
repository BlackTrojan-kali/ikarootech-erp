<?php $__env->startSection('content'); ?>
<center>
    <h1 class="text-xl font-bold">Ajouter un nouveau Role</h1>
    <form action="<?php echo e(route('store-role')); ?>" method="post" class="md:w-4/12 border-2 mt-2 p-5 border-blue-400 rounded-md">
        <?php echo csrf_field(); ?>
        <div class="champs">
            <label for="username">Nom:</label>
            <input type="text" name="role" required>
            <?php if($errors->has("role")): ?>
                <p class="text-red-500"> <?php echo e($errors->first('role')); ?></p>
            <?php endif; ?>
        </div>
        </div>
        <div class="w-full flex justify-between mt-4">
            <button type="reset" class="p-2 bg-black text-white">Annuler</button>
            <button type="submit" class="p-2 bg-blue-400 text-white">Enregistrer</button>
        </div>
    </form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/super/role_create.blade.php ENDPATH**/ ?>