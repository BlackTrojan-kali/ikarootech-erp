<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8"> 
        <h1 class="font-bold text-2xl text-center mb-6">État du Stock</h1> 

        <div class="overflow-x-auto shadow-md rounded-lg"> 
            <table class="min-w-full leading-normal"> 
                <thead class="text-white font-bold text-center bg-gray-700"> 
                    <tr>
                        <th class="px-5 py-3 border-b-2 border-gray-600 text-left text-xs font-semibold uppercase tracking-wider">S/L</th> 
                        <th class="px-5 py-3 border-b-2 border-gray-600 text-left text-xs font-semibold uppercase tracking-wider">Citerne</th>
                        <th class="px-5 py-3 border-b-2 border-gray-600 text-left text-xs font-semibold uppercase tracking-wider">Stock Théo.</th> 
                        <th class="px-5 py-3 border-b-2 border-gray-600 text-left text-xs font-semibold uppercase tracking-wider">Stock Rél.</th> 
                        <th class="px-5 py-3 border-b-2 border-gray-600 text-left text-xs font-semibold uppercase tracking-wider">Écart</th> 
                        <th class="px-5 py-3 border-b-2 border-gray-600 text-left text-xs font-semibold uppercase tracking-wider">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white"> 
                    <?php $__currentLoopData = $fixe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-100"> 
                            <td class="px-5 py-5 border-b border-gray-200 text-sm"><?php echo e($fix->id); ?></td>
                            <td class="px-5 py-5 border-b border-gray-200 text-sm"><?php echo e($fix->name); ?>-<?php echo e($fix->type); ?></td>
                            <td class="px-5 py-5 border-b border-gray-200 text-sm"><?php echo e($fix->stock[0]->stock_theo); ?></td>
                            <td class="px-5 py-5 border-b border-gray-200 text-sm"><?php echo e($fix->stock[0]->stock_rel); ?></td>
                            <?php
                                $ecart = $fix->stock[0]->stock_rel - $fix->stock[0]->stock_theo;
                            ?>
                            <td class="px-5 py-5 border-b border-gray-200 text-sm">
                                <?php if($ecart > 0): ?>
                                    <span class="text-green-600 font-semibold"><?php echo e($ecart); ?></span> 
                                <?php else: ?>
                                    <span class="text-red-600 font-semibold"><?php echo e($ecart); ?></span> 
                                <?php endif; ?>
                            </td>
                            <td class="px-5 py-5 border-b border-gray-200 text-sm">
                                <div class="flex flex-col space-y-2 items-center"> 
                                    <a href="<?php echo e(route('makeRel', ['id' => $fix->id])); ?>" class="block"> 
                                        <button class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-150 ease-in-out"> 
                                            Nouveau relevé
                                        </button>
                                    </a>
                                    <b class="block">
                                        <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded transition duration-150 ease-in-out"> 
                                            Modifier Stock Théo.
                                        </button>
                                    </b>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.ManagerLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\blacktrojan\Documents\ikarootech-erp\resources\views/manager/citernes.blade.php ENDPATH**/ ?>