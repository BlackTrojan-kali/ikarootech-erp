<?php $__env->startSection("content"); ?>

<center class="w-full p-4">
    <h1 class="mb-3 text-xl font-bold">Enregistrer un nouveau produit</h1>
    <form action="<?php echo e(route("insertArticle")); ?>" method="POST" class="p-4 border border-blue-400 rounded-lg w-5/12">
        <?php echo csrf_field(); ?>
        <div class="champs">
            <label for="title">Nom:</label>
            <input type="text" name="title" required>
            <?php if($errors->has("title")): ?>
                <p class="text-red-500"><?php echo e($errors->first('title')); ?></p>
            <?php endif; ?>
        </div>
        <div class="champs hidden">
            <label for="title">Poids:</label>
            <select name="poids" class="w-full p-3 font-bold" id="">
                <option value="12.5" selected>12.5 Kg</option>
                <option value="50">50 Kg</option>
                <option value="6">6 Kg</option>
            </select>
            <?php if($errors->has("poids")): ?>
                <p class="text-red-500"><?php echo e($errors->first('poids')); ?></p>
            <?php endif; ?>
        </div>
        <div class="champ text-start my-4 font-bold hidden">
        <label for="title">Etat:</label>
          <input type="radio" name="state" value="1" class="w-10" required disabled>Plein
        <input type="radio" name="state"  value="0" class="w-10" required disabled>Vide
        <br>

        <?php if($errors->has("state")): ?>
        <p class="text-red-500"><?php echo e($errors->first('state')); ?></p>
    <?php endif; ?>
        </div>
        <div class="text-start mt-2">
            <label for="" class="text-start">type:</label>
            <select name="type" id="" class="w-full p-2 font-bold" required>
                <option value="accessoire">Accessoire</option>
            </select>

            <?php if($errors->has("type")): ?>
                <p class="text-red-500"><?php echo e($errors->first('type')); ?></p>
            <?php endif; ?>
        </div>
        <br>
        <div class="w-full flex justify-end">
            <button class="text-white font-bold bg-blue-400 p-2" type="submit">Enregistrer </button>
        </div>
    </form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/super/addAccessory.blade.php ENDPATH**/ ?>