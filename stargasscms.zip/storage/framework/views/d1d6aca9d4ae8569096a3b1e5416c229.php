
<?php $__env->startSection('content'); ?>
    <center>
        <div class="flex flex-row justify-between p-4">
            <h1 class="text-2xl font-bold"> <?php echo e($type); ?> Global</h1>

            <button class="ternary p-2 text-white rounded-sm text-bold"><a href="<?php echo e(route('GsalesPdf')); ?>">generer un
                    PDF</a></button>
        </div>
        <div>
            <table class=" scroll text-center mt-10 w-full border-2 border-gray-400 border-collapse-0">
                <thead class="bg-gray-500 text-white p-2 border-collapse-0">
                    <tr>
                        <th>Date</th>
                        <th>Qte 6 KG</th>
                        <th>Qte 12.5 KG</th>
                        <th>Qte 50 kg</th>
                        <th>CA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($vente->mois); ?>/<?php echo e($vente->annee); ?> </td>
                            <td><?php echo e(number_format($vente->somme_qty_6, 2, ',', ' ')); ?></td>
                            <td><?php echo e(number_format($vente->somme_qty_12, 2, ',', ' ')); ?></td>
                            <td><?php echo e(number_format($vente->somme_qty_50, 2, ',', ' ')); ?></td>
                            <td><?php echo e(number_format($vente->total_gpl, 2, ',', ' ')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.DirectionLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/director/globalSales.blade.php ENDPATH**/ ?>