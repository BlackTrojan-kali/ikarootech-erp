
<?php $__env->startSection('content'); ?>
    <div>
        <!-- ventes FORMULAIRES -->
        <div>
            <center>
                <div class="modal-active w-full md-6/12">
                    <div class="modal-head">
                        <h1>Modifier <?php echo e($sale->type); ?></h1>
                        <b class="close-modal">X</b>
                    </div>
                    <b class="success text-green-500"></b>
                    <b class="errors text-red-500"></b>
                    <form action="<?php echo e(route('updateInvoice', $sale->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>


                        <div class="modal-champs">
                            <label for="">Somme recue:</label>
                            <input type="text" value="<?php echo e($sale->recieved); ?>" name="amount" value="<?php echo e($sale->customer); ?>"
                                required>
                            <?php if($errors->has('amount')): ?>
                                <b class="text-red-500"><?php echo e($errors->first('amount')); ?></b>
                            <?php endif; ?>
                        </div>
                        <div class="modal-champs">
                            <label for="">Type de Paiement</label>
                            <select name="currency">
                                <object data="<?php echo e($sale->currency); ?>" type=""><?php echo e($sale->currency); ?></object>
                                <option value="<?php echo e($sale->currency); ?>"><?php echo e($sale->currency); ?></option>
                                <option value="cash">Cash</option>

                                <option value="virement">Virement</option>
                            </select>
                            <?php if($errors->has('currency')): ?>
                                <b class="text-red-500"><?php echo e($errors->first('currency')); ?></b>
                            <?php endif; ?>
                        </div>
                        <div class="modal-validation">
                            <button type="reset">annuler</button>
                            <button type="submit" id="submitForm">modifier</button>
                        </div>
                    </form>
                </div>
            </center>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.comLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/commercial/ModifInvoice.blade.php ENDPATH**/ ?>