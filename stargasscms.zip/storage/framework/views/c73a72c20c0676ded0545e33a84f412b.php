<?php $__env->startSection("content"); ?>
<center>
    <h1 class="font-bold my-4">Depotage DE GPL VRAC</h1>
    <div>
        <table class=" scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
            <thead class="text-white font-bold bg-slate-600 p-2">
                <tr>
                    <td>S\L</td>
                    <td>Citerne_fixe</td>
                    <td>Citerne_mobile</td>
                    <td>Qte</td>
                    <td>matricule</td>
                    <td>date</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $depotages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reception): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id=<?php echo e($reception->id); ?> class="hover:bg-blue-400 hover:text-white cursor-pointer">
                        <td><?php echo e($reception->id); ?></td>
                        <td><?php echo e($reception->citerne_mobile->name); ?> (<?php echo e($reception->citerne_mobile->type); ?>)</td>
                        <td><?php echo e($reception->citerne_fixe->name); ?> (<?php echo e($reception->citerne_fixe->type); ?>)</td>
                        <td><?php echo e($reception->qty); ?></td>
                        <td><?php echo e($reception->matricule); ?></td>
                        <td><?php echo e($reception->created_at); ?></td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</center>
<script>
$( function () {
    $('table').DataTable();
    //evement sur les historiques
    //evement sur les historiques
    $(".delete").on("click",function(){
        id = $(this).parent().parent().attr("id");
   
        var token = $("meta[name='csrf-token']").attr("content");
        Swal.fire({
  title: "Etes vous sures ? cette operation est irreversible",
  showDenyButton: true,
  showCancelButton: true,
  confirmButtonText: "Supprimer",
  denyButtonText: `Annuler`
}).then((result) => {
  /* Read more about isConfirmed, isDenied below */
  if (result.isConfirmed) {
        $.ajax({
            url:"/producer/DeleteRec/"+id,
            dataType:"json",
            data: {
                "id": id,
                "_token": token,
            },
            method:"DELETE",
            success:function(res){
                toastr.warning(res.message)
                $("#"+id).load(location.href+ " #"+id)
            },
        }) } else if (result.isDenied) {
    Swal.fire("Changement non enregistre", "", "info");
  }
})
    })
})</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.producerLayout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/producer/depotages.blade.php ENDPATH**/ ?>