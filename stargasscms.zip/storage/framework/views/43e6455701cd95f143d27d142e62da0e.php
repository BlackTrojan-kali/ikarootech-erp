<?php $__env->startSection('content'); ?>
    <center>
        <h1 class="text-xl font-bold">Ajouter un nouvelle utilisateur</h1>
        <form action="<?php echo e(route('addUser')); ?>" method="post" class="md:w-4/12 border-2 mt-2 p-5 border-blue-400 rounded-md">
            <?php echo csrf_field(); ?>
            <div class="champs">
                <label for="username">Nom:</label>
                <input type="text" name="name" required>
                <?php if($errors->has('name')): ?>
                    <p class="text-red-500"> <?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
            </div>
            <div class="champs">
                <label for="email">Email:</label>
                <input type="email" name="email" required>
                <?php if($errors->has('email')): ?>
                    <p class="text-red-500"> <?php echo e($errors->first('email')); ?></p>
                <?php endif; ?>
            </div>
            <div class="champs">
                <label for="password">Mot de Passe:</label>
                <input type="password" name="password" required>

                <?php if($errors->has('password')): ?>
                    <p class="text-red-500"> <?php echo e($errors->first('password')); ?></p>
                <?php endif; ?>
            </div>
            <div class="champs">
                <label for="password">Confirmer Mot de Passe:</label>
                <input type="password" name="password_confirmation" required>

                <?php if($errors->has('password_confirmation')): ?>
                    <p class="text-red-500"> <?php echo e($errors->first('password_confirmation')); ?></p>
                <?php endif; ?>
            </div>
            <div class="w-full text-start">
                <label for="">Region:</label>
                <select name="region" id="" class="w-full text-center p-2 mt-2 mb-2">
                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($region->region); ?>"><?php echo e($region->region); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <option value="all">ALL(direction only)</option>
                </select>
            </div>
            <div class="w-full text-start">
                <label for="">Role:</label>
                <select name="role" id="" class="w-full text-center p-2 mt-2 mb-2">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->role); ?>"><?php echo e($role->role); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="w-full flex justify-between mt-4">
                <button type="reset" class="p-2 bg-black text-white">Annuler</button>
                <button type="submit" class="p-2 bg-blue-400 text-white">Enregistrer</button>
            </div>
        </form>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.appLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/super/addUser.blade.php ENDPATH**/ ?>