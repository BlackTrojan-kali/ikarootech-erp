<?php $__env->startSection("content"); ?>
<div class="p-5">
    <center class="flex justify-center gap-20">
        <button class="font-bold bg-blue-400 text-white p-4 text-2xl rounded-md hover:scale-90 transition-all duration-100"><a href="<?php echo e(route("addArticle")); ?>">Bouteilles de Gaz</a></button>
        <button class="font-bold border-2 border-black text-black p-4 text-2xl rounded-md hover:scale-90 transition-all duration-100"><a href="<?php echo e(route("addAccessory")); ?>">Accessoire</a></button>
    </center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/super/choseProductType.blade.php ENDPATH**/ ?>