<?php $__env->startSection('content'); ?> 
<h1 class="text-xl font-bold text-center">liste des Citernes</h1>
<div class="w-full gap-4 flex justify-end mb-4">
    <button class="bg-orange-400 text-white font-bold p-4 rounded-md "><a href="<?php echo e(route('addCiterns')); ?>">Ajouter une
            Citerne</a></button>

</div>
</table> 
<table class="w-full bg-orange-200 border-separate p-4 rounded-md text-center table-2">
    <thead class="font-bold">
        <tr>
            <td>Nom</td>
            <td>Type</td>
            <td>action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $citernes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citerne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($citerne->name); ?></td>
                <td><?php echo e($citerne->type); ?></td>
                <td><i id="<?php echo e($citerne->id); ?>"
                        class="delete-citern px-4 p-1 rounded-md bg-red-500 text-white cursor-pointer fa-solid fa-trash"></i>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
    <script>
        $(document).ready(function() {
            $(".delete").on("click", function(e) {
                e.preventDefault()
                articleId = $(this).attr('id');
                Swal.fire({
                    title: "Etes vous sures ? cette operation est irreversible",
                    showDenyButton: true,
                    showCancelButton: true,
                    confirmButtonText: "Supprimer",
                    denyButtonText: `Annuler`
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "DELETE",
                            url: "deleteArticle/" + articleId,
                            dataType: "json",
                            data: {
                                "id": articleId,
                                "_token": "<?php echo e(csrf_token()); ?>"
                            },
                            success: function(res) {
                                Swal.fire("element supprime avec success", "",
                                    "success");
                                $('table').load(" table")
                            }
                        })
                    } else if (result.isDenied) {
                        Swal.fire("Changement non enregistre", "", "info");
                    }
                });

            })




            $(".delete-citern").on("click", function(e) {
                e.preventDefault()
                citernId = $(this).attr('id');
                Swal.fire({
                    title: "Etes vous sures ? cette operation est irreversible",
                    showDenyButton: true,
                    showCancelButton: true,
                    confirmButtonText: "Supprimer",
                    denyButtonText: `Annuler`
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "DELETE",
                            url: "deleteCitern/" + citernId,
                            dataType: "json",
                            data: {
                                "id": citernId,
                                "_token": "<?php echo e(csrf_token()); ?>"
                            },
                            success: function(res) {
                                Swal.fire("element supprime avec success", "",
                                    "success");
                                $('.table-2').load(" .table-2")
                            }
                        })
                    } else if (result.isDenied) {
                        Swal.fire("Changement non enregistre", "", "info");
                    }
                });

            })
        })
    </script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.appLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/super/citernelist.blade.php ENDPATH**/ ?>