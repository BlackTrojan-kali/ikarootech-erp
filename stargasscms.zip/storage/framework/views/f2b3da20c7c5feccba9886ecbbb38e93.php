<?php $__env->startSection('content'); ?> 
<h1 class="text-xl font-bold text-center">liste des Stocks</h1>
<div class="w-full gap-4 flex justify-end mb-4">
    <button class="secondary text-white font-bold p-4 rounded-md "><a href="<?php echo e(route('add_stock')); ?>">Ajouter un Stock</a></button>

</div>

<table id="table-1" class="w-full table-auto bg-slate-200 border-separate p-2">
    <thead class="font-bold">
        <tr>
            <td>Article</td>
            <td>Type</td>
            <td>Poid</td>
            <td>Region</td>
            <td>Service</td>
            <td>action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>

                    <?php if($stock->article->title == "stargas"): ?>
                        <?php if($stock->article->state == 1): ?>
                            <?php echo e($stock->article->weight." ".$stock->article->unity." pleine"); ?>

                            <?php else: ?>

                            <?php echo e($stock->article->weight." ".$stock->article->unity." vide"); ?>

                        <?php endif; ?>
                        <?php else: ?>

                        <?php echo e($stock->article->title); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($stock->article->type); ?></td>
                <td><?php echo e($stock->article->weight); ?> <?php echo e($stock->article->unity); ?></td>
                <td><?php echo e($stock->region); ?></td>
                <td><?php echo e($stock->category); ?></td>
                <td><i id="<?php echo e($stock->id); ?>"
                        class="delete-citern px-4 p-1 rounded-md bg-red-500 text-white cursor-pointer fa-solid fa-trash"></i>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
    <script>
        $(document).ready(function() {
            $('table').DataTable();
            $(".delete").on("click", function(e) {
                e.preventDefault()
                articleId = $(this).attr('id');
                Swal.fire({
                    title: "Etes vous sures ? cette operation est irreversible",
                    showDenyButton: true,
                    showCancelButton: true,
                    confirmButtonText: "Supprimer",
                    denyButtonText: `Annuler`
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "DELETE",
                            url: "delete_stock/" + articleId,
                            dataType: "json",
                            data: {
                                "id": articleId,
                                "_token": "<?php echo e(csrf_token()); ?>"
                            },
                            success: function(res) {
                                Swal.fire("element supprime avec success", "",
                                    "success");
                                $('#table-1').load(" #table-1")
                            }
                        })
                    } else if (result.isDenied) {
                        Swal.fire("Changement non enregistre", "", "info");
                    }
                });

            })




            $("#table-1").on("click",".delete-citern", function(e) {
                e.preventDefault()
                citernId = $(this).attr('id');
                Swal.fire({
                    title: "Etes vous sures ? cette operation est irreversible",
                    showDenyButton: true,
                    showCancelButton: true,
                    confirmButtonText: "Supprimer",
                    denyButtonText: `Annuler`
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "DELETE",
                            url: "delete_stock/" + citernId,
                            dataType: "json",
                            data: {
                                "id": citernId,
                                "_token": "<?php echo e(csrf_token()); ?>"
                            },
                            success: function(res) {
                                Swal.fire("element supprime avec success", "",
                                    "success");
                                $('#table-1').load(" #table-1")
                            }
                        })
                    } else if (result.isDenied) {
                        Swal.fire("Changement non enregistre", "", "info");
                    }
                });

            })
        })
    </script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.appLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/super/stocksList.blade.php ENDPATH**/ ?>