
<?php $__env->startSection('content'); ?>

    <center>

        <h1>HISTORIQUES DES RELEVES</h1>

        <table class=" scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
            <thead class="bg-gray-500 text-white p-2 border-collapse-0">
                <tr>
                    <td>No</td>
                    <td>Citerne</td>
                    <td>Stock Theorique</td>
                    <td>Stock Releve</td>
                    <td>ecart</td>
                    <td>Date de Creation</td>
                    <td>Date de Modification</td>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($depotages->first())): ?>
                    <?php $__currentLoopData = $depotages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $move): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($move->id); ?>" class="hover:bg-blue-400 hover:text-white hover:cursor-pointer">
                            <td><?php echo e($move->id); ?></td>
                            <td>
                                <?php echo e($move->citerne); ?>

                            </td>
                            <td>
                                <?php echo e($move->stock_theo); ?></td>
                            <td>
                                <?php echo e($move->stock_rel); ?></td>
                            <td><?php echo e($move->stock_rel - $move->stock_theo); ?></td>
                            <td><?php echo e($move->created_at); ?></td>
                            <td><?php echo e($move->updated_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p> aucun resultat</p>
                <?php endif; ?>
            </tbody>
        </table>

    </center>

    <script>
        $(function() {
            $('table').DataTable();
            //evement sur les historiques
            /*$(".delete").on("click",function(){
                id = $(this).parent().parent().attr("id");
           
                var token = $("meta[name='csrf-token']").attr("content");
                Swal.fire({
          title: "Etes vous sures ? cette operation est irreversible",
          showDenyButton: true,
          showCancelButton: true,
          confirmButtonText: "Supprimer",
          denyButtonText: `Annuler`
        }).then((result) => {
          //Read more about isConfirmed, isDenied below 
          if (result.isConfirmed) {
                $.ajax({
                    url:"/manager/DeleteMove/"+id,
                    dataType:"json",
                    data: {
                        "id": id,
                        "_token": token,
                    },
                    method:"DELETE",
                    success:function(res){
                        toastr.warning(res.message)
                        $("#"+id).load(location.href+ " #"+id)
                    },
                }) } else if (result.isDenied) {
            Swal.fire("Changement non enregistre", "", "info");
          }
        })
            })*/
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.controllerLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/controller/history-transmit.blade.php ENDPATH**/ ?>