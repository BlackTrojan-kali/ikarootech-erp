
<?php $__env->startSection('content'); ?>
    <div class="w-full">
        <center>

            <div class="w-6/12 border-2 border-gray-300">
                <div class="modal-head">
                    <h1>Creer une nouvelle categorie client</h1>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" class="p-2" action="<?php echo e(route('update-client', ['id' => $client->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Nom:</label>
                        <input type="text" value="<?php echo e($client->nom); ?>" name="name">
                        <?php if($errors->has('name')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('name')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Prenom:</label>
                        <input type="text" value="<?php echo e($client->prenom); ?>" name="fname">
                        <?php if($errors->has('fname')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('fname')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Numero de telephone:</label>
                        <input type="number" value="<?php echo e($client->numero); ?>" name="phone">
                        <?php if($errors->has('phone')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('phone')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Adresse:</label>
                        <input type="text" value="<?php echo e($client->address); ?>" name="address">
                        <?php if($errors->has('address')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('address')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Email:</label>
                        <input type="email" value="<?php echo e($client->email); ?>" name="email">
                        <?php if($errors->has('email')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('email')); ?></b>
                        <?php endif; ?>
                    </div>

                    <div class="modal-champs">
                        <label for="">Categorie:</label>
                        <select name="category">
                            <option value="<?php echo e($client->id_clientcat); ?>"><?php echo e($client->Clientcat->name); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('email')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('email')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Reduction:</label>
                        <input type="number" value="<?php echo e($client->reduction); ?>" name="redux">
                        <?php if($errors->has('redux')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('redux')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Layouts.comLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/commercial/modif_client.blade.php ENDPATH**/ ?>