<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env('COMPANIE_NAME')); ?> SCMC</title>
</head>

<body>
    <style>
        table {
            width: 100%;
            border: 1px solid black;
            border-collapse: collapse;
        }

        tr,
        th,
        td {

            border: 1px solid black;
        }
    </style>
    <center>
        <div class="flex flex-row justify-between p-4">
            <h1 class="text-2xl font-bold">Versements Global <?php echo e($type); ?></h1>

        </div>
        <div>
            <table class=" scroll text-center mt-10 w-full border-2 border-gray-400 border-collapse-0">
                <thead class="bg-gray-500 text-white p-2 border-collapse-0 ">
                    <tr>
                        <th>Date</th>
                        <th>Versements</th>
                        <th>Bank</th>
                    </tr>
                </thead>
                <tbody class="text-start">
                    <?php $__currentLoopData = $versements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $versement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($versement->mois); ?>/<?php echo e($versement->annee); ?> </td>
                            <td><?php echo e(number_format($versement->total_gpl, 2, ',', ' ')); ?></td>
                            <td><?php echo e($versement->bank); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </center>
</body>

</html>
<?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/director/GcaPDF.blade.php ENDPATH**/ ?>