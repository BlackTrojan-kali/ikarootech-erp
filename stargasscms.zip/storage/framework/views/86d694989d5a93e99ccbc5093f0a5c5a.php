
<?php $__env->startSection('content'); ?>
    <center>
        <h1 class="font-bold text-2xl">Etat du Stock</h1>
        <table class=" scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
            <thead class="text-white font-bold text-center bg-slate-600 p-2">
                <tr>
                    <td>S/L</td>
                    <td>Citerne</td>
                    <td>Stock Theo</td>
                    <td>Stock Releve</td>
                    <td>Ecart</td>
                </tr>
            </thead>
            <tbody class="bg-orange-200 text-center">
                <?php $__currentLoopData = $fixe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($fix->id); ?></td>
                        <td><?php echo e($fix->name); ?>-<?php echo e($fix->type); ?></td>
                        <td><?php echo e($fix->stock[0]->stock_theo); ?></td>
                        <td><?php echo e($fix->stock[0]->stock_rel); ?></td>

                        <?php
                        $ecart = $fix->stock[0]->stock_rel - $fix->stock[0]->stock_theo;
                        ?>
                        <td>
                            <?php if($ecart > 0): ?>
                                <span class="text-green-500"><?php echo e($ecart); ?></span>
                            <?php else: ?>
                                <span class="text-red-500"><?php echo e($ecart); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.controllerLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/controller/citerne.blade.php ENDPATH**/ ?>