
<?php $__env->startSection('content'); ?>
    <div class="w-full">
        <center>

            <div class="w-6/12 border-2 border-gray-300">
                <div class="modal-head">
                    <h1>Modifier le prix client</h1>
                </div>
                <b class="success text-green-500"></b>
                <b class="errors text-red-500"></b>
                <form method="POST" class="p-2" action="<?php echo e(route('update-price', ['id' => $price->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Client:</label>
                        <input type="text" name="nom"
                            value="<?php echo e($price->client->nom . ' ' . $price->client->prenom); ?>" disabled>
                    </div>
                    <div class="modal-champs">
                        <label for="">Article:</label>
                        <?php if($price->article->type == 'accessoire'): ?>
                            <input type="text" name="article" value="<?php echo e($price->article->title); ?>" disabled>
                        <?php else: ?>
                            <input type="text" name="article"
                                value="<?php echo e($price->article->type . ' ' . $price->article->wieght . ' kg'); ?>" disabled>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label>Price:</label>
                        <input type="number" value="<?php echo e($price->unite_price); ?>" name="price" />
                        <?php if($errors->has('price')): ?>
                            <p class="text-red-500"><?php echo e($erros->first('price')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Prix Consigne:</label>
                        <input type="number" name="consigne_price" value="<?php echo e($price->consigne_price); ?>">
                        <?php if($errors->has('consigne_price')): ?>
                            <b class="text-red-500"><?php echo e($errors->first('consigne_price')); ?></b>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit">creer</button>
                    </div>
                </form>
            </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.appLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/super/edit-prices.blade.php ENDPATH**/ ?>