<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl  font-bold ">Versements a associer </h1>
    <br>
    <div>
        <table class="history scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
            <thead class="p-2 bg-gray-500 text-white">
                <tr>
                    <td>Bank</td>
                    <td>Montant_gpl</td>
                    <td>Montant_consigne</td>
                    <td>Commentaire</td>
                    <td>bordereau</td>
                    <td>Date</td>
                    <td>Action</td>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $versements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($verse->bank); ?></td>
                    <td><?php echo e($verse->montant_gpl); ?></td>
                    <td><?php echo e($verse->montant_consigne); ?></td>
                    <td><?php echo e($verse->commentaire); ?></td>
                    <td><?php echo e($verse->bordereau); ?></td>
                    <td><?php echo e($verse->created_at); ?></td>
                    <td>
                        <?php if($sale->id_versement != $verse->id): ?>
                        <a href="<?php echo e(route("versement_vente_dissoc",["id_vente"=>$sale->id,"id_versement"=>$verse->id])); ?>"> Dissocier</a>
                        <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <br>
 
    </div>
    <script>
        $(function() {
            $('table').DataTable();
            //evement sur les historiques
            $(".show-filter").on("click", function() {
                $(".filter-content").toggleClass("hidden")
            })
            $("#table-sales").on("click", "delete", function() {
                id = $(this).parent().parent().attr("id");

                var token = $("meta[name='csrf-token']").attr("content");
                $.ajax({
                    url: "/manager/DeleteMove/" + id,
                    dataType: "json",
                    data: {
                        "id": id,
                        "_token": token,
                    },
                    method: "DELETE",
                    success: function(res) {
                        toastr.warning(res.message)
                        $("#" + id).load(location.href + " #" + id)
                    },
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.comLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/parvatti/Documents/stargasscms/resources/views/commercial/vente_versement_detach.blade.php ENDPATH**/ ?>