@extends("Layouts.comLayout")

@section("content")

    {{-- MODALE POUR LA LISTE DES VENTES À ASSOCIER --}}
    {{-- Cette div sera stylisée comme une modale pour un meilleur UX --}}
    <div id="ventes-list-modal" class="modal-overlay fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50"> {{-- Utilisation des classes de modale du layout --}}
        <div class="modal-content bg-white p-6 rounded-md border border-black shadow-lg w-full max-w-4xl mx-auto my-8 overflow-y-auto max-h-[90vh]"> {{-- Styles conservés et améliorés --}}
            <div class="flex justify-end mb-4"> {{-- Boutons au-dessus du tableau --}}
                <a href="{{ route("showVentes","versements") }}" class="secondary text-white p-2 rounded-md">Fermer</a> {{-- Couleur 'secondary' conservée --}}
            </div>

            <h1 class="text-xl font-bold text-center mb-4">Liste des ventes à associer au versement</h1> {{-- Titre pour la clarté --}}

            <div class="flex justify-between items-center mb-4">
                <button class="primary text-white p-2 rounded-md" id="associate-button">Associer</button> {{-- Couleur 'primary' conservée --}}
                <div class="flex items-center">
                    <label for="all-checkbox" class="mr-2 text-gray-700">Sélectionner tout</label>
                    <input type="checkbox" id="all-checkbox" class="form-checkbox h-5 w-5 text-blue-600 rounded">
                </div>
            </div>

            <form id="associationForm" action="{{ route("assoc_versement_vente") }}" method="POST">
            @csrf
                <div class="overflow-x-auto"> {{-- Conteneur pour le défilement horizontal du tableau --}}
                    <table id="ventesTable" class="min-w-full leading-normal border border-black rounded-md"> {{-- Bordure noire conservée --}}
                        <thead class="bg-gray-200 text-gray-700"> {{-- Fond gris clair pour l'en-tête --}}
                            <tr>
                                <th class="px-5 py-3 border-b-2 border-black text-left text-xs font-semibold uppercase tracking-wider">Client</th> {{-- Bordure noire conservée --}}
                                <th class="px-5 py-3 border-b-2 border-black text-left text-xs font-semibold uppercase tracking-wider">Total Facture</th>
                                <th class="px-5 py-3 border-b-2 border-black text-left text-xs font-semibold uppercase tracking-wider">Mode de Paiement</th>
                                <th class="px-5 py-3 border-b-2 border-black text-left text-xs font-semibold uppercase tracking-wider">Type</th>
                                <th class="px-5 py-3 border-b-2 border-black text-left text-xs font-semibold uppercase tracking-wider">Date</th>
                                <th class="px-5 py-3 border-b-2 border-black text-left text-xs font-semibold uppercase tracking-wider">Sélection</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($invoices as $invoice ) {{-- Utilisation de @forelse pour gérer le cas où il n'y a pas de factures --}}
                                <tr class="hover:bg-gray-50">
                                    <td class="px-5 py-5 border-b border-gray-200 text-sm">{{ $invoice->client->nom." ".$invoice->client->prenom }}</td>
                                    <td class="px-5 py-5 border-b border-gray-200 text-sm">{{ $invoice->total_price }}</td>
                                    <td class="px-5 py-5 border-b border-gray-200 text-sm">{{ $invoice->currency }}</td>
                                    <td class="px-5 py-5 border-b border-gray-200 text-sm">{{ $invoice->type }}</td>
                                    <td class="px-5 py-5 border-b border-gray-200 text-sm">{{ $invoice->created_at->format('d/m/Y H:i') }}</td> {{-- Formatage de la date --}}
                                    <td class="px-5 py-5 border-b border-gray-200 text-sm">
                                        <input type="checkbox" class="vente-checkbox form-checkbox h-4 w-4 text-blue-600 rounded" value="{{ $invoice->id }}">
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="px-5 py-5 border-b border-gray-200 text-sm text-center text-gray-500">Aucune vente disponible pour l'association.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </div>

    <script type="module">
        $(function() {
            let id_versement = {{ $idVer }};
            let oTable = $('#ventesTable').DataTable({
                 // Options de configuration de DataTables, si nécessaire.
                 // Par exemple, pour désactiver le tri et la recherche par défaut si le tableau est petit et juste pour la sélection.
                "paging": false,
                "searching": false,
                "info": false,
            });

            // Gérer la sélection/désélection de toutes les cases à cocher
            $('#all-checkbox').click(function () {
                $('.vente-checkbox').prop('checked', $(this).is(':checked'));
            });

            // Gérer le clic sur le bouton "Associer"
            $('#associate-button').click(function() {
                var selectedVentes = [];
                $('.vente-checkbox:checked').each(function() {
                    selectedVentes.push($(this).val());
                });

                if (selectedVentes.length > 0) {
                    // Ajouter les champs cachés au formulaire
                    $('<input>').attr({
                        type: 'hidden',
                        name: 'ventes',
                        value: selectedVentes.join(',')
                    }).appendTo('#associationForm');
                    $('<input>').attr({
                        type: 'hidden',
                        name: 'versement',
                        value: id_versement
                    }).appendTo('#associationForm');

                    // Soumettre le formulaire
                    $('#associationForm').submit();
                } else {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Aucune sélection',
                        text: 'Veuillez sélectionner au moins une vente à associer.',
                        confirmButtonText: 'OK'
                    });
                }
            });

            // Fonction pour fermer la modale (si elle est utilisée comme telle)
            // J'ai renommé l'ID pour être plus descriptif et j'ai ajouté un bouton de fermeture explicite.
            $('#ventes-list-modal').removeClass('hidden'); // Assurez-vous que la modale est visible au chargement

            // Gérer la fermeture de la modale en cliquant sur le bouton "Fermer"
            $('#close').on('click', function(e) {
                e.preventDefault(); // Empêche le comportement par défaut du lien
                $('#ventes-list-modal').addClass('hidden');
                // Rediriger ou faire d'autres actions après la fermeture si nécessaire
            });

            // Gérer la fermeture de la modale en cliquant en dehors du contenu (si le background est un overlay)
            $('#ventes-list-modal').on('click', function(e) {
                if ($(e.target).is('#ventes-list-modal')) { // S'assure de cliquer sur l'overlay et non le contenu
                    $('#ventes-list-modal').addClass('hidden');
                }
            });


            // Suppression des fonctions de suppression de tables qui ne sont pas pertinentes pour cette page
            // car elles sont basées sur des IDs de table non présents (table1, table2, table3)
            // et le contexte de cette page est l'association de ventes à un versement, pas la suppression de versements.
            // Si ces fonctions sont nécessaires ailleurs, elles devraient être dans les pages/layouts appropriés.
        });
    </script>
@endsection