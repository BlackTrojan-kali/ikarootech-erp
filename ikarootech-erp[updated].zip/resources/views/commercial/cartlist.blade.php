@extends('Layouts.comLayout')

@section('content')
    <div class="container mx-auto px-4 "> {{-- Conteneur principal pour centrer et ajouter du padding --}}

        <div class="bg-white rounded-lg shadow-xl p-6 max-w-2xl mx-auto my-4"> {{-- Style pour le bloc principal --}}
            <div class="bg-slate-500 text-white p-4 rounded-t-lg flex justify-between items-center"> {{-- En-tête du bloc avec couleur originale --}}
                <h1 class="text-xl font-semibold">Formulaire de Ventes/Consigne</h1> {{-- Titre clair --}}
                <a href="{{ route('dashboardCom') }}" class="text-white hover:text-gray-200 text-2xl font-bold">&times;</a> {{-- Bouton de fermeture stylisé --}}
            </div>

            <h2 class="text-lg font-bold mt-6 mb-4 text-gray-700">Liste des éléments</h2> {{-- Titre pour la liste des éléments --}}
            <div class="flex flex-col gap-3 w-full p-2"> {{-- Espace entre les éléments de la liste --}}
                @forelse (Cart::content() as $row) {{-- Utilisation de @forelse pour gérer le cas où le panier est vide --}}
                    <div class="font-semibold w-full flex flex-col md:flex-row items-center justify-between gap-4 p-3 shadow-md rounded-lg bg-slate-200 border border-gray-200"> {{-- Couleur de fond originale --}}
                        <h3 class="text-gray-800 text-base md:text-lg mb-2 md:mb-0">
                            {{ $row->name == 'stargas' ? 'Bouteille-gaz' : $row->name }}
                            @if ($row->weight > 0)
                                <span class="text-gray-700">{{ $row->weight }} kg</span> {{-- Couleur ajustée --}}
                            @endif
                        </h3>
                        <form class="flex flex-col md:flex-row items-center gap-3 w-full md:w-auto" method="POST" action="{{ route('updateCart', [$row->rowId]) }}">
                            @csrf
                            <input type="hidden" name="rowId" value="{{ $row->rowId }}">
                            <div class="flex items-center gap-2">
                                <label for="qty-{{ $row->rowId }}" class="text-gray-700 text-sm">Quantité:</label>
                                <input id="qty-{{ $row->rowId }}" disabled class="bg-gray-300 border border-black p-2 rounded-md w-20 text-center" type="number" name="qtyup" value="{{ $row->qty }}"> {{-- Couleurs originales --}}
                            </div>
                            <div class="flex gap-2 h-10 items-center">
                                <a href="{{ route('deleteItem', ['id' => $row->rowId]) }}" class="bg-red-500 text-white p-2 rounded-md">Supprimer</a> {{-- Couleur originale --}}

                                {{-- Si le bouton modifier est remis, le styliser comme suit :
                                <button type="submit" class="bg-gray-200 p-2 rounded-md border border-black">Modifier</button>
                                --}}
                            </div>
                        </form>
                    </div>
                @empty
                    <p class="text-center text-gray-500 py-4">Aucun article selectionne.</p>
                @endforelse
            </div>

            <div class="text-center mt-6 mb-8">
                <button id="add-products-form-button" class="p-2 text-white primary rounded-md shadow-md"> {{-- Classe 'primary' conservée --}}
                    Sélectionner un article
                </button>
            </div>

            <form method="POST" class="p-4 border-t border-gray-200 mt-4" action="{{ route('validateCart') }}">
                @csrf
                <div class="mb-4"> {{-- Utilisation de mb-x pour l'espacement --}}
                    <label for="client" class="block text-gray-700 text-sm font-bold mb-2">Client:</label>
                    <select name="client" id="client" class="clients w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> {{-- Bordure noire conservée --}}
                        @foreach ($clients as $client)
                            <option value="{{ $client->id }}">{{ $client->nom . ' ' . $client->prenom }}</option>
                        @endforeach
                    </select>
                    @error('client')
                        <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p> {{-- Couleur originale --}}
                    @enderror
                </div>
                <div class="mb-4">
                    <label for="currency" class="block text-gray-700 text-sm font-bold mb-2">Mode de paiement:</label>
                    <select name="currency" id="currency" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> {{-- Bordure noire conservée --}}
                        <option value="Cash">Cash</option>
                        <option value="Virement">Virement</option>
                    </select>
                    @error('currency')
                        <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p> {{-- Couleur originale --}}
                    @enderror
                </div>
                <div class="mb-6"> {{-- Marge plus grande pour le dernier champ avant les boutons --}}
                    <label for="operation_type" class="block text-gray-700 text-sm font-bold mb-2">Type d'opération:</label>
                    <select name="type" id="operation_type" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> {{-- Bordure noire conservée --}}
                        <option value="vente">Vente</option>
                        <option value="consigne">Consigne</option>
                    </select>
                    @error('type') {{-- Correction de l'erreur pour le champ 'type' --}}
                        <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p> {{-- Couleur originale --}}
                    @enderror
                </div>
                <div class="flex justify-end gap-3 mt-4"> {{-- Alignement des boutons à droite avec espacement --}}
                    <button type="reset" class="p-2 bg-black text-white rounded-md">Annuler</button> {{-- Couleur originale --}}
                    <button type="submit" class="p-2 primary text-white rounded-md">Valider</button> {{-- Classe 'primary' conservée --}}
                </div>
            </form>
        </div>
    </div>

    {{-- MODALE POUR SÉLECTIONNER UN ARTICLE --}}
    <div id="add-products" class="modal-overlay hidden fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
        <div class="modal-content bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-auto relative transform transition-all sm:my-8 sm:w-full">
            <div class="modal-head flex justify-between items-center border-b pb-3 mb-4">
                <h1 class="text-xl font-semibold text-gray-800">Sélectionner un Article</h1>
                <button type="button" class="close-modal text-gray-400 hover:text-gray-600 text-2xl font-bold">&times;</button> {{-- Couleur du 'X' conservée --}}
            </div>
            <span class="success text-green-500 block mb-2"></span> {{-- Couleur originale --}}
            <span class="errors text-red-500 block mb-4"></span> {{-- Couleur originale --}}
            <form method="POST" action="{{ route('addTocart') }}">
                @csrf
                <div class="mb-4">
                    <label for="article" class="block text-gray-700 text-sm font-bold mb-2">Article:</label>
                    <select name="article" id="article" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> {{-- Bordure noire conservée --}}
                        @foreach ($articles as $article)
                            <option value="{{ $article->id }}">
                                {{ $article->type == 'accessoire' ? $article->title : $article->type . ' ' . $article->weight . ' KG' }}
                            </option>
                        @endforeach
                    </select>
                    @error('article')
                        <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p> {{-- Couleur originale --}}
                    @enderror
                </div>
                <div class="mb-6">
                    <label for="qty" class="block text-gray-700 text-sm font-bold mb-2">Quantité:</label>
                    <input type="number" name="qty" id="qty" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300" required> {{-- Bordure noire conservée --}}
                    @error('qty')
                        <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p> {{-- Couleur originale --}}
                    @enderror
                </div>
                <div class="flex justify-end gap-3">
                    <button type="reset" class="p-2 bg-gray-500 text-white rounded-md close-modal">Annuler</button> {{-- Couleur originale (btn-secondary) --}}
                    <button type="submit" id="submitForm" class="p-2 primary text-white rounded-md">Ajouter</button> {{-- Classe 'primary' conservée --}}
                </div>
            </form>
        </div>
    </div>

    <script type="module">
        $(document).ready(function() {
            // Initialisation de Select2
            $(".clients").select2({
                placeholder: "Sélectionnez un client",
                allowClear: true // Optionnel: permet de désélectionner
            });

            // Fonction pour ouvrir une modale
            function openModal(modalId) {
                $('#' + modalId).removeClass('hidden');
            }

            // Fonction pour fermer toutes les modales
            function closeModals() {
                $('.modal-overlay').addClass('hidden');
                // Optionnel: Réinitialiser les champs de formulaire ou les messages d'erreur/succès ici
                $('.success').text('');
                $('.errors').text('');
            }

            // Ouvrir la modale "Sélectionner un article"
            $("#add-products-form-button").on("click", function(e) {
                e.preventDefault();
                openModal('add-products');
            });

            // Fermer les modales via le bouton "X" ou "Annuler"
            $('.close-modal').on("click", function(e) {
                e.preventDefault();
                closeModals();
            });

            // Fermer la modale en cliquant en dehors du contenu de la modale
            $('.modal-overlay').on('click', function(e) {
                if ($(e.target).hasClass('modal-overlay')) {
                    closeModals();
                }
            });
        });
    </script>
@endsection