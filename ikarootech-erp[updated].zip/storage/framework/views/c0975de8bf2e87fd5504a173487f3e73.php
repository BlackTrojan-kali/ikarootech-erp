<?php $__env->startSection('content'); ?>
    <h1 class="text-center font-bold text-2xl my-4">Accueil</h1>

    
    <div class="w-full px-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10 info">
        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Calcul du pourcentage de remplissage, en supposant que 30000 est la capacité maximale
                $maxCapacity = 30000;
                $percent = ($stock->qty / $maxCapacity) * 100;
                // Assurer que le pourcentage ne dépasse pas 100% et n'est pas négatif
                $percent = max(0, min(100, $percent));
            ?>
            <div class="relative w-full"> 
                <div class="w-11/12 flex justify-between font-bold items-center"> 
                    <p>
                        <?php echo e(env('COMPANIE_NAME')); ?>

                        <span class="general">
                            <?php echo e($stock->article->weight > 0 ? $stock->article->weight . 'kg' : ''); ?>

                        </span>
                        <?php if($stock->type == 'bouteille-gaz'): ?>
                            <span class="text-green-500"><?php echo e($stock->article->state ? 'pleine' : 'vide'); ?></span>
                        <?php endif; ?>
                    </p>
                    <p><?php echo e($stock->qty); ?></p>
                </div>
                <div class="w-full bg-gray-300 h-8 rounded-e-full relative overflow-hidden"> 
                    <div class="primary h-8 top-0 rounded-e-full absolute" style="width:<?php echo e($percent); ?>%"></div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.ManagerLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/blacktrojan/Documents/lab/ikarootech-erp/resources/views/manager/dashboard.blade.php ENDPATH**/ ?>