<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 "> 

        <div class="bg-white rounded-lg shadow-xl p-6 max-w-2xl mx-auto my-4"> 
            <div class="bg-slate-500 text-white p-4 rounded-t-lg flex justify-between items-center"> 
                <h1 class="text-xl font-semibold">Formulaire de Ventes/Consigne</h1> 
                <a href="<?php echo e(route('dashboardCom')); ?>" class="text-white hover:text-gray-200 text-2xl font-bold">&times;</a> 
            </div>

            <h2 class="text-lg font-bold mt-6 mb-4 text-gray-700">Liste des éléments</h2> 
            <div class="flex flex-col gap-3 w-full p-2"> 
                <?php $__empty_1 = true; $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <div class="font-semibold w-full flex flex-col md:flex-row items-center justify-between gap-4 p-3 shadow-md rounded-lg bg-slate-200 border border-gray-200"> 
                        <h3 class="text-gray-800 text-base md:text-lg mb-2 md:mb-0">
                            <?php echo e($row->name == 'stargas' ? 'Bouteille-gaz' : $row->name); ?>

                            <?php if($row->weight > 0): ?>
                                <span class="text-gray-700"><?php echo e($row->weight); ?> kg</span> 
                            <?php endif; ?>
                        </h3>
                        <form class="flex flex-col md:flex-row items-center gap-3 w-full md:w-auto" method="POST" action="<?php echo e(route('updateCart', [$row->rowId])); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="rowId" value="<?php echo e($row->rowId); ?>">
                            <div class="flex items-center gap-2">
                                <label for="qty-<?php echo e($row->rowId); ?>" class="text-gray-700 text-sm">Quantité:</label>
                                <input id="qty-<?php echo e($row->rowId); ?>" disabled class="bg-gray-300 border border-black p-2 rounded-md w-20 text-center" type="number" name="qtyup" value="<?php echo e($row->qty); ?>"> 
                            </div>
                            <div class="flex gap-2 h-10 items-center">
                                <a href="<?php echo e(route('deleteItem', ['id' => $row->rowId])); ?>" class="bg-red-500 text-white p-2 rounded-md">Supprimer</a> 

                                
                            </div>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center text-gray-500 py-4">Aucun article selectionne.</p>
                <?php endif; ?>
            </div>

            <div class="text-center mt-6 mb-8">
                <button id="add-products-form-button" class="p-2 text-white primary rounded-md shadow-md"> 
                    Sélectionner un article
                </button>
            </div>

            <form method="POST" class="p-4 border-t border-gray-200 mt-4" action="<?php echo e(route('validateCart')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-4"> 
                    <label for="client" class="block text-gray-700 text-sm font-bold mb-2">Client:</label>
                    <select name="client" id="client" class="clients w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> 
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($client->id); ?>"><?php echo e($client->nom . ' ' . $client->prenom); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label for="currency" class="block text-gray-700 text-sm font-bold mb-2">Mode de paiement:</label>
                    <select name="currency" id="currency" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> 
                        <option value="Cash">Cash</option>
                        <option value="Virement">Virement</option>
                    </select>
                    <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-6"> 
                    <label for="operation_type" class="block text-gray-700 text-sm font-bold mb-2">Type d'opération:</label>
                    <select name="type" id="operation_type" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> 
                        <option value="vente">Vente</option>
                        <option value="consigne">Consigne</option>
                    </select>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                        <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="flex justify-end gap-3 mt-4"> 
                    <button type="reset" class="p-2 bg-black text-white rounded-md">Annuler</button> 
                    <button type="submit" class="p-2 primary text-white rounded-md">Valider</button> 
                </div>
            </form>
        </div>
    </div>

    
    <div id="add-products" class="modal-overlay hidden fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
        <div class="modal-content bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-auto relative transform transition-all sm:my-8 sm:w-full">
            <div class="modal-head flex justify-between items-center border-b pb-3 mb-4">
                <h1 class="text-xl font-semibold text-gray-800">Sélectionner un Article</h1>
                <button type="button" class="close-modal text-gray-400 hover:text-gray-600 text-2xl font-bold">&times;</button> 
            </div>
            <span class="success text-green-500 block mb-2"></span> 
            <span class="errors text-red-500 block mb-4"></span> 
            <form method="POST" action="<?php echo e(route('addTocart')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="article" class="block text-gray-700 text-sm font-bold mb-2">Article:</label>
                    <select name="article" id="article" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300"> 
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($article->id); ?>">
                                <?php echo e($article->type == 'accessoire' ? $article->title : $article->type . ' ' . $article->weight . ' KG'); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['article'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-6">
                    <label for="qty" class="block text-gray-700 text-sm font-bold mb-2">Quantité:</label>
                    <input type="number" name="qty" id="qty" class="w-full p-2 border border-black rounded-md focus:outline-none focus:ring focus:border-blue-300" required> 
                    <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="flex justify-end gap-3">
                    <button type="reset" class="p-2 bg-gray-500 text-white rounded-md close-modal">Annuler</button> 
                    <button type="submit" id="submitForm" class="p-2 primary text-white rounded-md">Ajouter</button> 
                </div>
            </form>
        </div>
    </div>

    <script type="module">
        $(document).ready(function() {
            // Initialisation de Select2
            $(".clients").select2({
                placeholder: "Sélectionnez un client",
                allowClear: true // Optionnel: permet de désélectionner
            });

            // Fonction pour ouvrir une modale
            function openModal(modalId) {
                $('#' + modalId).removeClass('hidden');
            }

            // Fonction pour fermer toutes les modales
            function closeModals() {
                $('.modal-overlay').addClass('hidden');
                // Optionnel: Réinitialiser les champs de formulaire ou les messages d'erreur/succès ici
                $('.success').text('');
                $('.errors').text('');
            }

            // Ouvrir la modale "Sélectionner un article"
            $("#add-products-form-button").on("click", function(e) {
                e.preventDefault();
                openModal('add-products');
            });

            // Fermer les modales via le bouton "X" ou "Annuler"
            $('.close-modal').on("click", function(e) {
                e.preventDefault();
                closeModals();
            });

            // Fermer la modale en cliquant en dehors du contenu de la modale
            $('.modal-overlay').on('click', function(e) {
                if ($(e.target).hasClass('modal-overlay')) {
                    closeModals();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.comLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/blacktrojan/Documents/lab/ikarootech-erp/resources/views/commercial/cartlist.blade.php ENDPATH**/ ?>